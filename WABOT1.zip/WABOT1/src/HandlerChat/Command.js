"use strict";
require("dotenv").config();
require("../../src/Database/JsDB/JSON.js");
const {modul, infos, switch_, INDEXml} = require("../../src/WhatsApp/Validator/Config");
const {menu} = require("../../src/WhatsApp/Validator/Catatan"); 
const {mess} = require("../../src/WhatsApp/Validator/Mess"); 
const {fs, chalk, util, fetch, baileys, brainly} = modul;
const {owner} = infos;
const {buggc, multipref, oneprefix, noprefix} = switch_
const {MessageType} = baileys;
const {asmaulhusna} = INDEXml;

const hasCommand = async({rojak, EM, isAntilink, isDeleted, isWelkom, botNumber, isPengunjung, isCatchPengunjung, itsMe, prefix, content, from, type, sender, isGroup, isOwner, mentionTag, mentionReply, mention, mentionUser, cmd, body, messagesC, args, totalchat, buff, isCmd, command, groupMetadata, groupDesc, groupName, groupId, groupMembers, groupAdmins, isBotGroupAdmins, isGroupAdmins, conts, pushname, isButton, isListMessage, isMedia, isImage, isVideo, isStickers, isListMsg, isQuotedMsg, isQuotedImage, isQuotedAudio, isQuotedVideo, isQuotedSticker, isQuotedDocument, isQuotedContact, isQuotedProduct, isQuotedLocation}) => {
try {
    switch (command) {
         case "test": {
       await rojak.sendText(from, "Work 100%", { quoted: EM })
      }
      break;
         case "cutrani1": {
       await rojak.sendMessage(from, fs.readFileSync('./src/Database/MusicMP3/cutrani/cutrani_1.mp3'), MessageType.audio, { quoted: EM, mimetype: 'audio/mp4', ptt:true })
      }
      break;
         case "cutrani2": {
       await rojak.sendMessage(from, fs.readFileSync('./src/Database/MusicMP3/cutrani/cutrani_2.mp3'), MessageType.audio, { quoted: EM, mimetype: 'audio/mp4', ptt:true })
      }
      break;
         case "menu": {
      let pkgg = require("../../package.json");
      let speed = require('performance-now');
      let timestamp = speed();
      let latensi = speed() - timestamp;
      let l = 1;
       await rojak.sendButtonImg(from, buff, menu("✎ᝰ┆", l++, prefix, sender.split("@")[0], pushname, '0' + sender.split("@")[0].slice(2), botNumber.split("@")[0], require("../../src/WhatsApp/Functions/visitor").pengunjung.length, `${switch_.isPublic ? "PUBLIK" : "SELF"}`, owner[0], rojak.kyun(process.uptime()), latensi.toFixed(4), "0 -Rp", require('crypto').randomBytes(5).toString('hex').toUpperCase()), pkgg.description, 'Marketplace', 'BUTTON_MARKETPLACE', EM, { contextInfo: { mentionedJid: [ sender, botNumber, owner[0] + '@s.whatsapp.net' ] } })
      }
      break;
         case "antilinkgroup": {
      if(!isGroup) return await rojak.sendText(from, mess.only.group, { quoted: EM });
      if(!isOwner) return await rojak.sendText(from, mess.only.owner, { quoted: EM });
      if(args.length < 1) return await rojak.sendText(from, `example:\n\n${prefix}${command} enable/disable`, { quoted: EM });
      if((args[0]) === 'enable') {
      if(isAntilink) return await rojak.sendText(from, 'Udah aktif', { quoted: EM });
       antilinkgroup.push(from);
       fs.writeFileSync('./src/Database/JsonDB/antilinkgroup/antilinkgroup.json', JSON.stringify(antilinkgroup));
       await rojak.sendText(from, `Sukses mengaktifkan fitur ${command} di group ini ✔️`, { quoted: EM });
      } else if((args[0]) === 'disable') {
       antilinkgroup.splice(from, 1);
       fs.writeFileSync('./src/Database/JsonDB/antilinkgroup/antilinkgroup.json', JSON.stringify(antilinkgroup));
       await rojak.sendText(from, `Sukses menonaktifkan fitur ${command} di group ini ✔️`, { quoted: EM });
      } else {
       await rojak.sendText(from, 'Enable untuk mengaktifkan, disable untuk menonaktifkan', { quoted: EM });
      };
        };
      break;
         case "welcome": {
      if(!isGroup) return await rojak.sendText(from, mess.only.group, { quoted: EM });
      if(!isOwner) return await rojak.sendText(from, mess.only.owner, { quoted: EM });
      if(args.length < 1) return await rojak.sendText(from, `example:\n\n${prefix}${command} enable/disable`, { quoted: EM });
      if((args[0]) === 'enable') {
      if(isWelkom) return await rojak.sendText(from, 'Udah aktif', { quoted: EM });
       welkom.push(from);
       fs.writeFileSync('./src/Database/JsonDB/welcome/welcome.json', JSON.stringify(welkom));
       await rojak.sendText(from, `Sukses mengaktifkan fitur ${command} di group ini ✔️`, { quoted: EM });
      } else if((args[0]) === 'disable') {
       welkom.splice(from, 1);
       fs.writeFileSync('./src/Database/JsonDB/welcome/welcome.json', JSON.stringify(welkom));
       await rojak.sendText(from, `Sukses menonaktifkan fitur ${command} di group ini ✔️`, { quoted: EM });
      } else {
       await rojak.sendText(from, 'Enable untuk mengaktifkan, disable untuk menonaktifkan', { quoted: EM });
      };
        };
      break;
         case "antidelete": {
      if(!isGroup) return await rojak.sendText(from, mess.only.group, { quoted: EM });
      if(!isOwner) return await rojak.sendText(from, mess.only.owner, { quoted: EM });
      if(args.length < 1) return await rojak.sendText(from, `example:\n\n${prefix}${command} enable/disable`, { quoted: EM });
      if((args[0]) === 'enable') {
      if(isDeleted) return await rojak.sendText(from, 'Udah aktif', { quoted: EM });
       antidelete.push(from);
       fs.writeFileSync('./src/Database/JsonDB/antidelete/antidelete.json', JSON.stringify(antidelete));
       await rojak.sendText(from, `Sukses mengaktifkan fitur ${command} di group ini ✔️`, { quoted: EM });
      } else if((args[0]) === 'disable') {
       antidelete.splice(from, 1);
       fs.writeFileSync('./src/Database/JsonDB/antidelete/antidelete.json', JSON.stringify(antidelete));
       await rojak.sendText(from, `Sukses menonaktifkan fitur ${command} di group ini ✔️`, { quoted: EM });
      } else {
       await rojak.sendText(from, 'Enable untuk mengaktifkan, disable untuk menonaktifkan', { quoted: EM });
      };
        };
      break;
         case "public": {
      if(!isOwner) return await rojak.sendText(from, mess.only.owner, { quoted: EM });
       switch_.isPublic = true
       await rojak.sendText(from, `Berhasil Mengubah Mode Bot Ke ${switch_.isPublic ? "PUBLIK" : "SELF"}`, { quoted: EM })
      }
      break;
         case "self": {
      if(!isOwner) return await rojak.sendText(from, mess.only.owner, { quoted: EM });
       switch_.isPublic = false
       await rojak.sendText(from, `Berhasil Mengubah Mode Bot Ke ${switch_.isPublic ? "PUBLIK" : "SELF"}`, { quoted: EM })
      }
      break;
         case "mode": {
       await rojak.sendText(from, `MODE BOT: ${switch_.isPublic ? "PUBLIK" : "SELF"}`, { quoted: EM })
      }
      break;
         case "checkdetector": {
       await rojak.sendText(from, `*WELCOME:* ${isWelkom ? "AKTIF" : "MATI"}\n*ANTI DELETE:* ${isDeleted ? "AKTIF" : "MATI"}\n*ANTI LINK GROUP:* ${isAntilink ? "AKTIF" : "MATI"}`, { quoted: EM })
      }
      break;
         case "tagall": {
      if(!isGroup) return await rojak.sendText(from, mess.only.group)
      if(!isGroupAdmins && !itsMe && !isOwner) return reply(mess.only.admin, { quoted: EM })
      if(!isBotGroupAdmins) return await rojak.sendText(from, mess.only.Badmin, { quoted: EM });
      let q = args.join(' ') 
      let arr = [];
      let txti = `*[ TAG ALL ]*\n\n${q ? q : ''}\n\n`
      for (let i of groupMembers){
      txti += `=> @${i.jid.split("@")[0]}\n`
      arr.push(i.jid)
      }
      rojak.mentions(from, txti, arr, true, null)
      }
      break
         case "kali": {
      let angka = args[0]
      let kaliberapa = args[2]
      let hasilnya = angka * kaliberapa
       await rojak.sendText(from, `${hasilnya}`, { quoted: EM })
      };
      break;
         case "kurang": {
      let angka = args[0]
      let kurangberapa = args[2]
      let hasilnya = angka - kurangberapa
       await rojak.sendText(from, `${hasilnya}`, { quoted: EM })
      };
      break;
         case "tambah": {
      let angka = args[0]
      let tambahberapa = args[2]
      let hasilnya = angka + tambahberapa
       await rojak.sendText(from, `${hasilnya}`, { quoted: EM })
      };
      break;
         case "bagi": {
      let angka = args[0]
      let bagiberapa = args[2]
      let hasilnya = angka / bagiberapa
       await rojak.sendText(from, `${hasilnya}`, { quoted: EM })
      };
      break;
         case "brainly": {
      let teks = '';
      let brien = args.join(' ')
      brainly(`${brien}`).then(res => {
      for (let Y of res.data) {
      teks += `\n*───────「 BRAINLY 」───────*\n\n*❶ Pertanyaan📄:* ${Y.pertanyaan}\n\n*❷ Jawaban📖:* ${Y.jawaban[0].text}\n`
      }
        rojak.sendText(from, teks, { quoted: EM });       
      }).catch(e => {
        rojak.sendText(from, `errr`, { quoted: EM });
      })
        };
      break;
         case "clearchat": {
      if(!isOwner) return await rojak.sendText(from, mess.only.owner, { quoted: EM });
       await rojak.setMaxListeners(25)
       await rojak.modifyChat(from, 'clear', { includeStarred: false })
       await rojak.sendText(from, `Total Chat Yang di ${command}: 1`, { quoted: EM });
      };
      break;
         case "deletechat": {
      if(!isOwner) return await rojak.sendText(from, mess.only.owner, { quoted: EM });
       await rojak.setMaxListeners(25)
       await rojak.modifyChat(from, 'delete', { includeStarred: false })
       await rojak.sendText(from, `Total Chat Yang di ${command}: 1`, { quoted: EM });
      };
      break;
         case "archivechat": {
      if(!isOwner) return await rojak.sendText(from, mess.only.owner, { quoted: EM });
       await rojak.setMaxListeners(25)
       await rojak.modifyChat(from, 'archive', { includeStarred: false })
       await rojak.sendText(from, `Total Chat Yang di ${command}: 1`, { quoted: EM });
      };
      break;
         case "unarchivechat": {
      if(!isOwner) return await rojak.sendText(from, mess.only.owner, { quoted: EM });
       await rojak.setMaxListeners(25)
       await rojak.modifyChat(from, 'unarchive', { includeStarred: false })
       await rojak.sendText(from, `Total Chat Yang di ${command}: 1`, { quoted: EM });
      };
      break;
         case "clearallchat": {
      if(!isOwner) return await rojak.sendText(from, mess.only.owner, { quoted: EM });
       await rojak.setMaxListeners(25)
       let yy;
      for (yy of totalchat) {
       await rojak.modifyChat(yy.jid, 'clear', { includeStarred: false })
      }
       await rojak.sendText(from, `Total Chat Yang di ${command}: ${totalchat.length}`, { quoted: EM });
      };
      break;
         case "deleteallchat": {
      if(!isOwner) return await rojak.sendText(from, mess.only.owner, { quoted: EM });
       await rojak.setMaxListeners(25)
       let yy;
      for (yy of totalchat) {
       await rojak.modifyChat(yy.jid, 'delete', { includeStarred: false })
      }
       await rojak.sendText(from, `Total Chat Yang di ${command}: ${totalchat.length}`, { quoted: EM });
      };
      break;
         case "archiveallchat": {
      if(!isOwner) return await rojak.sendText(from, mess.only.owner, { quoted: EM });
       await rojak.setMaxListeners(25)
       let yy;
      for (yy of totalchat) {
       await rojak.modifyChat(yy.jid, 'archive', { includeStarred: false })
      }
       await rojak.sendText(from, `Total Chat Yang di ${command}: ${totalchat.length}`, { quoted: EM });
      };
      break;
         case "unarchiveallchat": {
      if(!isOwner) return await rojak.sendText(from, mess.only.owner, { quoted: EM });
       await rojak.setMaxListeners(25)
       let yy;
      for (yy of totalchat) {
       await rojak.modifyChat(yy.jid, 'unarchive', { includeStarred: false })
      }
       await rojak.sendText(from, `Total Chat Yang di ${command}: ${totalchat.length}`, { quoted: EM });
      };
      break;
         case "asmaulhusna": {
      let q = await cmd.slice(command.length + 1, cmd.length);
      let json = JSON.parse(JSON.stringify(asmaulhusna))
      let link = json.map((v, i) => `${i + 1}. ${v.latin}\n${v.arabic}\n${v.translation_id}`).join('\n\n')
      if(isNaN(args[0])) return await rojak.sendText(from, `contoh:\n${prefix}${command} 1`, { quoted: EM })
      if(args[0]) {
      if(args[0] < 1 || args[0] > 99) return await rojak.sendText(from, `minimal 1 & maksimal 99!`, { quoted: EM })
      let { index, latin, arabic, translation_id, translation_en } = json.find(v => v.index == args[0].replace(/[^0-9]/g, ''))
      return rojak.sendText(from, `No. ${index}\n\n${arabic}\n${latin}\n\n${translation_id}\n${translation_en}`, { quoted: EM })
      }
      let contoh = `*Asmaul Husna*\n\n`
      let anjuran = `\n\nDari Abu hurarirah radhiallahu anhu, Rasulullah Saw bersabda: "إِنَّ لِلَّهِ تَعَالَى تِسْعَةً وَتِسْعِينَ اسْمًا، مِائَةٌ إِلَّا وَاحِدًا، مَنْ أَحْصَاهَا دخل الجنة، وهو وتر يُحِبُّ الْوِتْرَ"
      let Artinya: "Sesungguhnya Allah mempunyai sembilan puluh sembilan nama, alias seratus kurang satu. Barang siapa yang menghitung-hitungnya, niscaya masuk surga; Dia Witir dan menyukai yang witir".`
       await rojak.sendText(from, contoh + link + anjuran, { quoted: EM })
      };
      break;
         case "kisahnabi": {
      const pkgg = require('../../package.json');
      const __path = process.cwd() 
      let qq = await cmd.slice(command.length + 1, cmd.length);
      let boda = qq.slice(1)
      let o = 1;
      if(!boda) return await rojak.sendText(from, `contoh:\n${prefix}${command} adam`, { quoted: EM })
      try {
      new Promise(async (resolve, reject) => {
      let scraper = JSON.parse(fs.readFileSync(__path +`/src/Database/InputJSON/kisahnabi/${boda}.json`))
       console.log({scraper})
      let result = { name: scraper.name, kelahiran: scraper.thn_kelahiran +' sebelum massehi', wafat_usia: scraper.usia +' tahun', singgah: scraper.tmp, thumb: scraper.image_url, kisah: scraper.description }
       resolve(result)
       exports.result = result;
       await rojak.sendButtonImg(from, await (await fetch(result.thumb)).buffer(), `🤍 *Nama:* ${result.name}\n👶 *Lahir:* ${result.kelahiran}\n⚰️ *Wafat:* ${result.wafat_usia}\n🌐 *Singgah:* ${result.singgah}\n🖼️ *Gambar:* ${result.thumb}\n⏳ *Kisah:* ${result.kisah}\n*`, pkgg.description, "Beri Kami Peringkat?", "BUTTON_PERINGKAT", EM, { mimetype: "image/png", pngThumbnail: await (await fetch(result.thumb)).buffer() })
      })
        } catch (err) {
          console.log({err})
        }
      };
      break;
      };
      require('./FunctionsResponse')(rojak, EM, isAntilink, isDeleted, isWelkom, botNumber, isPengunjung, isCatchPengunjung, itsMe, prefix, content, from, type, sender, isGroup, isOwner, mentionTag, mentionReply, mention, mentionUser, cmd, body, messagesC, args, totalchat, buff, isCmd, command, groupMetadata, groupDesc, groupName, groupId, groupMembers, groupAdmins, isBotGroupAdmins, isGroupAdmins, conts, pushname, isButton, isListMessage, isMedia, isImage, isVideo, isStickers, isListMsg, isQuotedMsg, isQuotedImage, isQuotedAudio, isQuotedVideo, isQuotedSticker, isQuotedDocument, isQuotedContact, isQuotedProduct, isQuotedLocation)
      require('./ButtonResponse')(rojak, EM, isAntilink, isDeleted, isWelkom, botNumber, isPengunjung, isCatchPengunjung, itsMe, prefix, content, from, type, sender, isGroup, isOwner, mentionTag, mentionReply, mention, mentionUser, cmd, body, messagesC, args, totalchat, buff, isCmd, command, groupMetadata, groupDesc, groupName, groupId, groupMembers, groupAdmins, isBotGroupAdmins, isGroupAdmins, conts, pushname, isButton, isListMessage, isMedia, isImage, isVideo, isStickers, isListMsg, isQuotedMsg, isQuotedImage, isQuotedAudio, isQuotedVideo, isQuotedSticker, isQuotedDocument, isQuotedContact, isQuotedProduct, isQuotedLocation)
    } catch (err) {
      console.log({err})
    };
  };

module.exports = { hasCommand } 

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})