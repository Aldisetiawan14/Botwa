"use strict";
require("dotenv").config();
const {modul} = require("../../src/WhatsApp/Validator/Config");
const {fs, chalk, baileys, moment, child_process} = modul;
const {MessageType, mentionedJid} = baileys;
const {antideleteText} = require("../../src/WhatsApp/Validator/Catatan");
const {mess, style} = require("../../src/WhatsApp/Validator/Mess"); 
const {exec} = child_process;

module.exports = async(rojak, EM, isAntilink, isDeleted, isWelkom, botNumber, isPengunjung, isCatchPengunjung, itsMe, prefix, content, from, type, sender, isGroup, isOwner, mentionTag, mentionReply, mention, mentionUser, cmd, body, messagesC, args, totalchat, buff, isCmd, command, groupMetadata, groupDesc, groupName, groupId, groupMembers, groupAdmins, isBotGroupAdmins, isGroupAdmins, conts, pushname, isButton, isListMessage, isMedia, isImage, isVideo, isStickers, isListMsg, isQuotedMsg, isQuotedImage, isQuotedAudio, isQuotedVideo, isQuotedSticker, isQuotedDocument, isQuotedContact, isQuotedProduct, isQuotedLocation) => {
try {
    if(cmd.startsWith(prefix)) {
    console.log(chalk.blueBright("\nCommand dari :"), chalk.greenBright(`${pushname} =>`), chalk.yellowBright(`${prefix}${command}`));
    } else {
    console.log("\nPesan Dari :", { pushname, sender, cmd, type, args });
    }
    if(isCmd) {
    require("../../src/WhatsApp/Functions/visitor").pengunjung.push(sender);
    fs.writeFileSync('./src/Database/JsonDB/pengunjung/pengunjung.json', JSON.stringify(require("../../src/WhatsApp/Functions/visitor").pengunjung));
    require("../../src/WhatsApp/Functions/visitor").addPengunjung(sender, rojak.createSerial(20));
    }
    if(isCmd) {
    if(prefix && command) require("../../src/WhatsApp/Functions/totalcmd").cmdadd()
    rojak.hit_today = []
    await rojak.hit_today.push(command)
    }
    if(EM.message && EM.quoted && EM.quoted.mtype === 'orderMessage' && !(EM.quoted.token && EM.quoted.orderId)) {
    await rojak.sendText(EM.key.remoteJid, 'Fake Troli Detected\n\n' + require('util').format(EM.key), { quoted: EM })
    }
    if(EM.key.remoteJid.endsWith('broadcast')) {
    if(EM.key.fromMe) {
    if(EM.key.remoteJid.endsWith('@g.us')) {
    let pkgg = require("../../package.json")
    let name = rojak.getName(sender)
    let pc = JSON.parse(fs.readFileSync('./src/Database/JsonDB/firstchat/firstchat.json'))
    pc.push(sender, + new Date )
    fs.writeFileSync('./src/Database/JsonDB/firstchat/firstchat.json', JSON.stringify(pc))
    if( new Date - pc < 86400000 ) {
    let capt = `Hai ${name} ${rojak.ucapan()}\n\nSaya adalah Bot Auto Downloader\nKalau ingin tahu Fitur lainnya klik tombol dibawah ya`
    await rojak.send2ButtonLoc(EM.key.remoteJid, await ( await fetch('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRABEfk8DT2XA3wiM2fcKwU_fuKlp77oZEl0A&usqp=CAU')).buffer(), capt, pkgg.description, 'Menu', 'menu', 'Cek Prefix', 'cekprefix', EM)
    }
    }
    }
    }
    if(isOwner) {
    if(cmd.startsWith("<< ")) { 
    try {
    let evaled = await eval(cmd.slice(2))
    if(typeof evaled !== 'string') evaled = require('util').inspect(evaled)
    await rojak.sendText(from, `${evaled}`, { quoted: EM })
    console.log({evaled});
    } catch (err) {
    await rojak.sendText(from, `${err}`, { quoted: EM })
    console.log({err});
    }
    }
    if(isOwner) {
    if(cmd.startsWith('>> ')) {
    try {
    let evaled = eval(`(async () => { ${cmd.slice(3)} })()`)
    if(typeof evaled !== 'string' ) evaled = require('util').inspect(evaled);
    rojak.sendText(from, `${evaled}`, { quoted: EM })
    console.log({evaled});
    } catch (err) {
    rojak.sendText(from, `${err}`, { quoted: EM })
    console.log({err});
    }
    }
    if(isOwner) {
    if(cmd.startsWith("$ ")) {
    exec(cmd.slice(2), (err, stdout) => {
    if(err) return rojak.sendText(from, stdout, { quoted: EM }) 
    if(qstdout) return rojak.sendText(from, stdout, { quoted: EM })
    })
    }
    }
    if(cmd.includes("://chat.whatsapp.com/")){
    if(!isGroup) return;
    if(!isAntilink) return;
    if(isGroupAdmins) return await rojak.sendText(from, mess.adminBebas, { quoted: EM });
    await rojak.sendText(from, `Link Group Terdeteksi!\n\n Maaf @${sender.split("@")[0]}, Anda dikeluarkan dalam grup.`, { quoted: EM, contextInfo : { mentionedJid: [sender] } })
    if(isBotGroupAdmins) {
    await rojak.sendText(from, mess.adminBebas, { quoted: EM })
    }
    await rojak.groupRemove(from, [`${sender.split("@")[0]}@s.whatsapp.net`]).catch((e)=> rojak.logger.error(e))
    await rojak.send2ButtonLoc(sender, buff, 'Lain kali, Kalau mau masuk grup, baca dulu peraturan grup ya dek!.', pkgg.description, 'ALASAN', 'BUTTON_ALASAN_ANTILINK', 'DONASI', 'BUTTON_DONASI', EM)
    }
    if(cmd.includes(`${botNumber.split("@")[0]}`) && isGroup) {
    let pkgg = require("../../package.json")
    await rojak.send2ButtonImg(from, buff, `Halo @${sender.split("@")[0]}, ada yang bisa ${pkgg.name} bantu?\n`, pkgg.description, 'ADA', 'BUTTON_ADA', 'TIDAK', 'BUTTON_TIDAK', EM, { mentionedJid: [ '@6289677040051', sender ] })
    }
    if(cmd.includes('Assalamualaikum') && isGroup) {
    if(!itsMe) return;
    await rojak.sendText(from, "Waalaikumussalam Warahmatullahi Wabarakatuh", { quoted : EM })
    }
    if(isOwner) {
    if(cmd.toLowerCase() === ">>") {
    await rojak.sendText(from, "Maaf eval async tidak di ketahui", { quoted : EM })
    }
    }
    if(isOwner) {
    if(cmd.toLowerCase() === "<<") {
    await rojak.sendText(from, "Maaf eval return tidak di ketahui", { quoted : EM })
    }
    }
    if(isOwner) {
    if(cmd.toLowerCase() === "$") {
    await rojak.sendText(from, "Maaf exec tidak di ketahui", { quoted : EM })
    }
    }
    if((EM.mtype === 'groupInviteMessage' || cmd.startsWith('https://chat') || cmd.startsWith('Buka tautan ini')) && !EM.isBaileys && !EM.key.remoteJid.endsWith('@g.us')) {
    let pkgg = require("../../package.json");
    await rojak.sendText(EM.key.remoteJid, `*INGIN MENGUNDANG BOT KE GRUP ANDA?*\nIzin Ke Owner Dulu ya!\nJangan Lupa Donasi Bot Biar on terus`, { quoted: EM })
    await rojak.sendContact2(EM.key.remoteJid, owner[0] + "@s.whatsapp.net", pkgg.author, EM).then(() => {
    rojak.sendText(owner[0] + "@s.whatsapp.net", "Seseorang Mengirim Undangan Grup", { quoted: EM })
    })
    }
    }
    }
    } catch (err) {
    console.log({err})
    }
    }

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})