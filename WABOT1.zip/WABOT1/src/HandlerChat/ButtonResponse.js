"use strict";
require("dotenv").config();
const {modul} = require("../../src/WhatsApp/Validator/Config");
const {fs, chalk} = modul;

module.exports = async(rojak, EM, isAntilink, isDeleted, isWelkom, botNumber, isPengunjung, isCatchPengunjung, itsMe, prefix, content, from, type, sender, isGroup, isOwner, mentionTag, mentionReply, mention, mentionUser, cmd, body, messagesC, args, totalchat, buff, isCmd, command, groupMetadata, groupDesc, groupName, groupId, groupMembers, groupAdmins, isBotGroupAdmins, isGroupAdmins, conts, pushname, isButton, isListMessage, isMedia, isImage, isVideo, isStickers, isListMsg, isQuotedMsg, isQuotedImage, isQuotedAudio, isQuotedVideo, isQuotedSticker, isQuotedDocument, isQuotedContact, isQuotedProduct, isQuotedLocation) => {
try {
       if(isButton === "BUTTON_MARKETPLACE") {
       const pkgg = require('../../package.json');
       let button = {
             title: `Di Berdaya Oleh ${pkgg.author}`,
             buttonText: `Tekan Disini`,
             footerText: `${pkgg.description}`, 
             description: `\nHay @${sender.split('@')[0]}, Berikut Adalah Marketplace ${pkgg.name}\n\nBelanja Apapun Selalu Tersedia Disini!.`
          }
       let rows = [ 
          {
             title: "Topup Gaming [ Diamond - Credits - Item ]", 
             description: "Mobile Legend/Call Of Duty Mobile/Free Fire/Etc.",
             rowId: "LIST_TOPUPGAMING"
          }, 
       {
             title: "Topup Pulsa [ Vocher - Paket - Saldo ]",
             description: "Telkomsel/Three/Axis/XL/Indosat/Etc.",
             rowId: "LIST_TOPUPPULSA"
          }, 
       {
             title: "Panel Sosmed [ View - Followers - Insight - Subscribers ]",
             description: "Youtube/Instagram/Facebook/Twitter/Etc.",
             rowId: "LIST_PANELSOSMED"
          }
       ];
          await rojak.sendListM(from, button, rows, EM, { 
             contextInfo: { 
                mentionedJid: [ sender ]
             }
          })
       }
    } catch (err) {
      console.log({err})
    }
 }
   
let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})
   