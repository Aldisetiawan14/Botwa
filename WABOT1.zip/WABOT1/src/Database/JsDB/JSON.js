"use strict";
require("dotenv").config();
const {modul} = require("../../WhatsApp/Validator/Config");
const {fs, chalk} = modul;

global.welkom = JSON.parse(fs.readFileSync('./src/Database/JsonDB/welcome/welcome.json'))
global.antidelete = JSON.parse(fs.readFileSync('./src/Database/JsonDB/antidelete/antidelete.json'))
global.antilinkgroup = JSON.parse(fs.readFileSync('./src/Database/JsonDB/antilinkgroup/antilinkgroup.json'))

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})