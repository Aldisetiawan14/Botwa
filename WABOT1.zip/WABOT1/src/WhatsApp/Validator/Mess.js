"use strict";
require("dotenv").config();
const {modul} = require("./Config");
const {fs, chalk} = modul;

const mess = {
       adminBebas: 'Admin bebas',  
       wait: 'Loading...',
       success: 'Succes...',
       wrongFormat: 'Format salah, coba liat lagi di menu', 
       error: { 
       api: 'Ups, terjadi kesalahan', 
       stick: 'bukan sticker itu:v', 
       Iv: 'Link tidak valid' 
       }, 
       only: { 
       group: 'Maaf! Command ini khusus untuk di dalam Group saja.', 
       admin: 'Maaf! Command ini khusus untuk admin group saja.', 
       premium: 'Kamu bukan user premium, kirim perintah *!buypremium* untuk membeli premium', 
       owner: 'Maaf! Command ini khusus untuk Owner Bot saja.', 
       Badmin: 'Maaf! Command ini khusus untuk Bot ketika jadi admin!!' 
       }, 
    }
const style = {
       panahKanan: {
       type_1: '➤'
       },
    }
module.exports = { mess, style }

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})