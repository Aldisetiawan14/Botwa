"use strict";
require("dotenv").config();
const fs = require("fs");
const chalk = require("chalk");

module.exports = {
modul: {
	axios: require("axios"), 
	brainly: require("brainly-scraper"), 
	baileys: require("@adiwajshing/baileys"), 
	chalk: require("chalk"), 
	crypto: require("crypto"), 
	color: require("color"), 
	child_process: require("child_process"), 
	fs: require("fs"),
	ffmpeg: require("fluent-ffmpeg"), 
	FileType: require("file-type"), 
	fetch: require("node-fetch"), 
	figlet: require("figlet"), 
	got: require("got"), 
	moment: require("moment-timezone"),
	path: require("path"), 
	PhoneNumber: require("awesome-phonenumber"), 
	request: require("request"),
	syntaxerror: require("syntax-error"), 
	util: require("util")
  },
switch_: {
    isPublic: true, 
    multipref: false, 
    oneprefix: true, 
    noprefix: false
   },
infos: {
    owner: ["6281361057300", "0"],
    Qrcode_Sesi: "qrcode-terminal", 
    preff: [ "#" ]
   }, 
INDEXml: {
    asmaulhusna: require("../../../src/Database/InputJS/asmaulhusna/asmaulhusna").asmaulhusna
   }
};

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})