"use strict";
require("dotenv").config();
const {modul} = require("./Config");
const {fs, chalk} = modul;

  /**
  * menu
  * @param {String} style1
  * @param {String} style2
  * @param {String} prefix
  * @param {String} mentionedJid
  * @param {String} nama
  * @param {String} bio
  * @param {String} botTag
  * @param {String} Total_pengunjung 
  * @param {String} mode
  * @param {String} mode
  * @param {String} aktif
  * @param {String} fast
  */
exports.menu = (style1, style2, prefix, mentionedJid, nama, bio, botTag, Total_pengunjung, mode, dev, aktif, fast, duet, id) => {
  return `Hai! @${mentionedJid} 👋🏻

 ${style1} *INFORMASI*

 *DATA @${mentionedJid}:*
🖊️ Nama : ${nama}
🛍️ Pendapatan : ${duet}
🧳 ID : ${id} 

 *DATA @${botTag}:*
🔑 Mode Bot : ${mode}
📊 Total Pengunjung : ${Total_pengunjung}
🧠 Developer : @${dev}
⏳ Aktif Selama : ${aktif}
🚀 Kecepatan : ${fast} ms


 ${style1} *PENGGUNA GRATIS*

 *Islami:* 
${style2++}. ${prefix}kisahnabi query 
${style2++}. ${prefix}asmaulhusna 1 - 99

 *Lainnya:*
${style2++}. ${prefix}test
${style2++}. ${prefix}menu 
${style2++}. ${prefix}mode
${style2++}. ${prefix}checkdetector

 *Kalkulator:*
${style2++}. ${prefix}tambah angka + angka
${style2++}. ${prefix}kurang angka - angka 
${style2++}. ${prefix}kali angka × angka
${style2++}. ${prefix}bagi angka ÷ angka

 *Pertanyaan:*
${style2++}. ${prefix}brainly query


 ${style1} *KHUSUS OWNER*

 *Aksesibilitas:*
${style2++}. ${prefix}public
${style2++}. ${prefix}self
${style2++}. ${prefix}welcome enable/disable 
${style2++}. ${prefix}antidelete enable/disable
${style2++}. ${prefix}antilinkgroup enable/disable

 *Pembersihan:*
${style2++}. ${prefix}clearchat
${style2++}. ${prefix}deletechat
${style2++}. ${prefix}archivechat
${style2++}. ${prefix}unarchivechat
${style2++}. ${prefix}clearallchat
${style2++}. ${prefix}deleteallchat
${style2++}. ${prefix}archiveallchat
${style2++}. ${prefix}unarchiveallchat

 *Suara:*
${style2++}. ${prefix}cutrani1
${style2++}. ${prefix}cutrani2
`
}


  /**
  * callText
  * @param {String} *
  */
exports.callText = () => {
  return `Otomatis Di Blokir Oleh System!, Tolong Jamgan Telepon Nomor Ini.
`
}

  /**
  * antiBug
  * @param {String} *
  */
exports.antiBug = (teks, mention) => { 
  return `\`\`\`TANDAI TELAH DIBACA !!!\`\`\`${text}\`\`\`@⁨${mention} Terdeteksi Telah Mengirim Bug, @⁨${mention} Akan Dikick!\`\`\`\n
`
}

  /**
  * restrictf
  * @param {String} *
  */
exports.restrictf = () => {
  return `- [ Group Setting Change ] -

Edit Group info telah dibuka untuk member
Sekarang semua member dapat mengedit info Group Ini
`
}

  /**
  * restrictt
  * @param {String} *
  */
exports.restrictt = () => {
  return `- [ Group Setting Change ] -

Edit Group info telah ditutup untuk member
Sekarang hanya admin group yang dapat mengedit info Group Ini
`
} 

  /**
  * annaouncefalse
  * @param {String} *
  */
exports.announcefalse = () => {
  return `- [ Group Opened ] -
  
_Group telah dibuka oleh admin_
_Sekarang semua member bisa mengirim pesan_
`
}

  /**
  * annaouncetrue
  * @param {String} *
  */ 
exports.announcetrue = () => {
  return `- [ Group Closed ] -

_Group telah ditutup oleh admin_
_Sekarang hanya admin yang dapat mengirim pesan_
`
}

  /**
  * anndesc
  * @param {String} style
  * @param {String} tag
  * @param {String} desc
  */ 
exports.anndesc = (style, tag, desc) => {
  return `- [ Group Description Change ] -

Deskripsi Group telah diubah oleh Admin @${tag}
${style} Deskripsi Baru : ${desc}
`
}

  /**
  * antideleteText
  * @param {String} style1
  * @param {String} style2
  * @param {String} tagPush
  * @param {String} type
  * @param {String} jam
  * @param {String} week
  * @param {String} weton
  * @param {String} calender
  */
exports.antideleteText = (style1, style2, tagPush, type, jam, week, weton, calender) => {
  return `${style1} \`\`\`Anti Delete\`\`\`

${style2} \`\`\`Nama : @${tagPush}\`\`\`
${style2} \`\`\`Tipe : ${type}\`\`\`
${style2} \`\`\`Tanggal : ${jam} - ${week} ${weton} - ${calender}\`\`\`\n
`
}

  /**
  * Infaq
  * @param {String} style
  */
exports.textInfaq = (style) => {
  return `*KEUNGGULAN DONASI INFAQ* :

${style} Pembangunan
${style} Biaya Pendidikan Yatim
${style} Dhuʼafa Operasional Dakwah
${style} Pahala Jariyah
${style} Lainnya.
`
}

  /**
  * welcome
  * @param {String} mentionpush
  * @param {String} groupname
  */
exports.welcome = (mentionpush, groupname) => {
  return `Assalamualaikum @${mentionpush}, Selamat datang di grup *${groupname}* Semoga betah! dan jangan lupa intro ya.
`
}

  /**
  * leave
  * @param {String} mentionpush
  * @param {String} groupname
  */
exports.leave = (mentionpush, groupname) => {
  return `@${mentionpush}, Telah keluar dari grup *${groupname}*.
`
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})