"use strict";
require("dotenv").config();
const {modul} = require("../Validator/Config");
const {fs, chalk} = modul;

const ceemde = JSON.parse(fs.readFileSync('./src/Database/JsonDB/totalcmd/totalcmd.json'))

/**
 * for add total command
 * @params {direktori} 
 * dah lah
**/
const cmdadd = () => {
	ceemde[0].totalcmd += 1
	fs.writeFileSync('./src/Database/JsonDB/totalcmd/totalcmd.json', JSON.stringify(ceemde))
}

module.exports = {
	cmdadd
}

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})