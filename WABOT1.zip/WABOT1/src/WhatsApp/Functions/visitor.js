"use strict";
require("dotenv").config();
const {modul} = require("../Validator/Config");
const {fs, chalk} = modul;

// Json
const pengunjung = JSON.parse(fs.readFileSync('./src/Database/JsonDB/pengunjung/pengunjung.json'));

// Mengambil Total
const getPengunjung = () => {
    return pengunjung[Math.floor(Math.random() * pengunjung.length)].id
};

// Create JSON Verify
const addPengunjung = (usr, sender, age, time, serials) => {
    let obj = { id: usr, name: sender, age: age, time: time, serial: serials }
    pengunjung.push(obj)
    fs.writeFileSync('./src/Database/JsonDB/pengunjung/pengunjung.json', JSON.stringify(pengunjung))
};
        
// Verifiy Checker
const cekPengunjung = (sender) => {
    let status = false
    Object.keys(pengunjung).forEach((i) => {
    if (pengunjung[i].id === sender) {
    status = true
    }
    })
    return status
};

exports.getPengunjung = getPengunjung;
exports.addPengunjung = addPengunjung;
exports.cekPengunjung = cekPengunjung;
exports.pengunjung = pengunjung;

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})