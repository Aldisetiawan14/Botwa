"use strict";
require("dotenv").config();
const {modul} = require("../Validator/Config");
const {crypto, figlet, path, fs, axios, chalk, FileType, fetch, baileys, PhoneNumber, tmpdir, child_process, util, request, got, moment} = modul;
const {exec, spawn} = child_process;
const {WAConnection, ReconnectMode, MessageType, WAMessageProto, DEFAULT_ORIGIN, getAudioDuration, MessageTypeProto, Presence, MessageOptions, MediaPathMap, Mimetype, MimetypeMap, compressImage, generateMessageID, randomBytes, getMediaKeys, aesEncrypWithIV, hmacSign, sha256, encryptedStream } = baileys;
const {toAudio, toPTT, toVideo} = require('./converter')

exports.WAConnection = _WAConnection => {
	class WAConnection extends _WAConnection {
		constructor(...args) {
      super(...args)
          if (!Array.isArray(this._events["CB:action,add:relay,message"])) this._events["CB:action,add:relay,message"] = [this._events["CB:action,add:relay,message"]]
               else this._events["CB:action,add:relay,message"] = [this._events["CB:action,add:relay,message"].pop()]
               this._events["CB:action,add:relay,message"].unshift(async function (json) {
                  try {
                        let m = json[2][0][2]
                        if (m.message && m.message.protocolMessage && m.message.protocolMessage.type == 0) {
                            let key = m.message.protocolMessage.key
                            let c = this.chats.get(key.remoteJid)
                            let a = c.messages.dict[`${key.id}|${key.fromMe ? 1 : 0}`]
                            let participant = key.fromMe ? this.user.jid : a.participant ? a.participant : key.remoteJid
                            let WAMSG = WAMessageProto.WebMessageInfo
                               this.emit("message-delete", { 
                                  key, 
                                  participant, 
                                  message: WAMSG.fromObject(WAMSG.toObject(a)) 
                               })
                            }
                        } catch (err) { 
                  console.log(err)
               }
          })
               this.on(`CB:action,,battery`, json => {
               this.battery = Object.fromEntries(Object.entries(json[2][0][1]).map(v => [v[0], eval(v[1])]))
          })
      this.sendFileFromUrl = this.sendFileFromURL = this.sendFile
  };
    /**
     * Exact Copy Forward
     * @param {String} jid
     * @param {Object} message
     * @param {Boolean} forceForward
     * @param {Object} options
     */
 async copyNForward(jid, message, forceForward = false, options = {}) {
      let vtype
      if (options.readViewOnce) {
        message.message = message.message && message.message.ephemeralMessage && message.message.ephemeralMessage.message ? message.message.ephemeralMessage.message : (message.message || undefined)
        vtype = Object.keys(message.message.viewOnceMessage.message)[0]
        delete (message.message && message.message.ignore ? message.message.ignore : (message.message || undefined))
        delete message.message.viewOnceMessage.message[vtype].viewOnce
        message.message = {
          ...message.message.viewOnceMessage.message
        }
      }
      let mtype = Object.keys(message.message)[0]
      let content = await this.generateForwardMessageContent(message, forceForward)
      let ctype = Object.keys(content)[0]
      let context = {}
      if (mtype != MessageType.text) context = message.message[mtype].contextInfo
      content[ctype].contextInfo = {
        ...context,
        ...content[ctype].contextInfo
      }
      const waMessage = await this.prepareMessageFromContent(jid, content, options ? {
        ...content[ctype],
        ...options,
        ...(options.contextInfo ? {
          contextInfo: {
            ...content[ctype].contextInfo,
            ...options.contextInfo
          }
        } : {})
      } : {})
      await this.relayWAMessage(waMessage)
      return waMessage
    }

    /**
    * cMod
    * @param {String} jid 
    * @param {*} message 
    * @param {String} text 
    * @param {String} sender 
    * @param {*} options 
    * @returns 
    */
 cMod(jid, message, text = '', sender = this.user.jid, options = {}) {
      let copy = message.toJSON()
      let mtype = Object.keys(copy.message)[0]
      let isEphemeral = mtype === 'ephemeralMessage'
      if (isEphemeral) {
        mtype = Object.keys(copy.message.ephemeralMessage.message)[0]
      }
      let msg = isEphemeral ? copy.message.ephemeralMessage.message : copy.message
      let content = msg[mtype]
      if (typeof content === 'string') msg[mtype] = text || content
      else if (content.caption) content.caption = text || content.caption
      else if (content.text) content.text = text || content.text
      if (typeof content !== 'string') msg[mtype] = { ...content, ...options }
      if (copy.participant) sender = copy.participant = sender || copy.participant
      else if (copy.key.participant) sender = copy.key.participant = sender || copy.key.participant
      if (copy.key.remoteJid.includes('@s.whatsapp.net')) sender = sender || copy.key.remoteJid
      else if (copy.key.remoteJid.includes('@broadcast')) sender = sender || copy.key.remoteJid
      copy.key.remoteJid = jid
      copy.key.fromMe = sender === this.user.jid
      return WAMessageProto.WebMessageInfo.fromObject(copy)
    }

    /**
     * genOrderMessage
     * @param {String} message 
     * @param {*} options 
     * @returns 
     */
 async genOrderMessage(message, options) {
      let m = {}
      switch (type) {
        case MessageType.text:
        case MessageType.extendedText:
          if (typeof message === 'string') message = { text: message }
          m.extendedTextMessage = WAMessageProto.ExtendedTextMessage.fromObject(message);
          break
        case MessageType.location:
        case MessageType.liveLocation:
          m.locationMessage = WAMessageProto.LocationMessage.fromObject(message)
          break
        case MessageType.contact:
          m.contactMessage = WAMessageProto.ContactMessage.fromObject(message)
          break
        case MessageType.contactsArray:
          m.contactsArrayMessage = WAMessageProto.ContactsArrayMessage.fromObject(message)
          break
        case MessageType.groupInviteMessage:
          m.groupInviteMessage = WAMessageProto.GroupInviteMessage.fromObject(message)
          break
        case MessageType.listMessage:
          m.listMessage = WAMessageProto.ListMessage.fromObject(message)
          break
        case MessageType.buttonsMessage:
          m.buttonsMessage = WAMessageProto.ButtonsMessage.fromObject(message)
          break
        case MessageType.image:
        case MessageType.sticker:
        case MessageType.document:
        case MessageType.video:
        case MessageType.audio:
          m = await this.prepareMessageMedia(message, type, options)
          break
        case 'orderMessage':
          m.orderMessage = WAMessageProto.OrderMessage.fromObject(message)
      }
      return WAMessageProto.Message.fromObject(m);
    }

    /**
     * waitEvent
     * @param {*} eventName 
     * @param {Boolean} is 
     * @param {Number} maxTries 
     * @returns 
     */
 waitEvent(eventName, is = () => true, maxTries = 25) {
      return new Promise((resolve, reject) => {
        let tries = 0
        let on = (...args) => {
          if (++tries > maxTries) reject('Max tries reached')
          else if (is()) {
            this.off(eventName, on)
            resolve(...args)
          }
        }
        this.on(eventName, on)
      })
    }

    /**
     * Send Contact
     * @param {String} from
     * @param {String|Number} nomor
     * @param {String} nama
     */
 async sendContact(from, nomor, nama) {
	const vcard = `VERSION:3.0\n`
	   + `FN:${nama}\n`
	   + `ORG:Kontak\n`
	   + `TEL;type=CELL;type=VOICE;waid=${nomor}:+${nomor}\n`
	   + `END:VCARD`
	       this.sendMessage(from, {
	         displayname : nama, 
	         vcard : vcard
	       }, 
	   MessageType.contact)
   };
    /**
     * Send Contact2
     * @param {String} jid
     * @param {String|Number} number
     * @param {String} name
     * @param {Object} quoted
     * @param {Object} options
     */
 async sendContact2(jid, number, name, quoted, options) {
      number = number.replace(/[^0-9]/g, '')
      let njid = number + "@s.whatsapp.net"
      let { isBusiness } = await this.isOnWhatsApp(njid) || { isBusiness: false }
      const vcard = `\nBEGIN:VCARD\n`
         + `VERSION:3.0\n`
         + `N:;${name.replace(/\n/g, '\\n')};;;\n`
         + `FN:${name.replace(/\n/g, '\\n')}\n`
         + `TEL;type=CELL;type=VOICE;waid=${number}:${PhoneNumber("+" + number).getNumber("international")}${isBusiness ? `\nX-WA-BIZ-NAME:${(this.contacts[njid].vname || this.getName(njid)).replace(/\n/, '\\n')}\n`
         + `X-WA-BIZ-DESCRIPTION:${((await this.getBusinessProfile(njid)).description || '').replace(/\n/g, '\\n')}\n` : ''}\n`
         + `END:VCARD`.trim();
         return await this.sendMessage(jid, {
            displayName: name,
            vcard: vcard
         }, 
            MessageType.contact, { 
         quoted, 
         ...options 
      })
   };

    /**
    * sendGroupV4Invite
    * @param {String} jid 
    * @param {*} participant 
    * @param {String} inviteCode 
    * @param {Number} inviteExpiration 
    * @param {String} groupName 
    * @param {String} caption 
    * @param {*} options 
    * @returns 
    */
 async sendGroupV4Invite(jid, participant, inviteCode, inviteExpiration, groupName = 'unknown subject', caption = 'Invitation to join my WhatsApp group', options = {}) {
      let msg = WAMessageProto.Message.fromObject({
        groupInviteMessage: WAMessageProto.GroupInviteMessage.fromObject({
          inviteCode,
          inviteExpiration: parseInt(inviteExpiration) || + new Date(new Date + (3 * 86400000)),
          groupJid: jid,
          groupName: groupName ? groupName : this.getName(jid),
          caption
        })
      })
      let message = await this.prepareMessageFromContent(participant, msg, options)
      await this.relayWAMessage(message)
      return message
    }

    /**
 * fetchRequest
 * @param {*} endpoint 
 * @param {String} method ('GET'|'POST')
 * @param {*} body 
 * @param {*} agent 
 * @param {*} headers 
 * @param {*} redirect 
 * @returns 
 */
    fetchRequest = async (
      endpoint,
      method = 'GET',
      body,
      agent,
      headers,
      redirect = 'follow'
    ) => {
      try {
        let res = await fetch(endpoint, {
          method,
          body,
          redirect,
          headers: { Origin: DEFAULT_ORIGIN, ...(headers || {}) },
          agent: agent || this.connectOptions.fetchAgent
        })
        return await res.json()
      } catch (e) {
        console.error(e)
        let res = await got(endpoint, {
          method,
          body,
          followRedirect: redirect == 'follow' ? true : false,
          headers: { Origin: DEFAULT_ORIGIN, ...(headers || {}) },
          agent: { https: agent || this.connectOptions.fetchAgent }
        })
        return JSON.parse(res.body)
      }
    }

    /**
     * prepareMessageMedia
     * @param {Buffer} buffer 
     * @param {*} mediaType 
     * @param {*} options 
     * @returns 
     */
    /** Prepare a media message for sending */
 async prepareMessageMedia(buffer, mediaType, options = {}) {
      await this.waitForConnection()

      if (mediaType === MessageType.document && !options.mimetype) {
        throw new Error('mimetype required to send a document')
      }
      if (mediaType === MessageType.sticker && options.caption) {
        throw new Error('cannot send a caption with a sticker')
      }
      if (!(mediaType === MessageType.image || mediaType === MessageType.video) && options.viewOnce) {
        throw new Error(`cannot send a ${mediaType} as a viewOnceMessage`)
      }
      if (!options.mimetype) {
        options.mimetype = MimetypeMap[mediaType]
      }
      let isGIF = false
      if (options.mimetype === Mimetype.gif) {
        isGIF = true
        options.mimetype = MimetypeMap[MessageType.video]
      }
      const requiresThumbnailComputation = (mediaType === MessageType.image || mediaType === MessageType.video) && !('thumbnail' in options)
      const requiresDurationComputation = mediaType === MessageType.audio && !options.duration
      const requiresOriginalForSomeProcessing = requiresDurationComputation || requiresThumbnailComputation

      const mediaKey = randomBytes(32)
      const mediaKeys = getMediaKeys(mediaKey, mediaType)
      const enc = aesEncrypWithIV(buffer, mediaKeys.cipherKey, mediaKeys.iv)
      const mac = hmacSign(Buffer.concat([mediaKeys.iv, enc]), mediaKeys.macKey).slice(0, 10)
      const body = Buffer.concat([enc, mac]) // body is enc + mac
      const fileSha256 = sha256(buffer)
      const fileEncSha256 = sha256(body)
      const {
        encBodyPath,
        bodyPath,
        fileLength,
        didSaveToTmpPath
      } = await encryptedStream(buffer, mediaType, requiresOriginalForSomeProcessing)
      // url safe Base64 encode the SHA256 hash of the body
      const fileEncSha256B64 = encodeURIComponent(
        fileEncSha256
          .toString('base64')
          .replace(/\+/g, '-')
          .replace(/\//g, '_')
          .replace(/\=+$/, '')
      )
      if (requiresThumbnailComputation) await this.generateThumbnail(bodyPath, mediaType, options)
      if (requiresDurationComputation) {
        try {
          options.duration = await getAudioDuration(bodyPath)
        } catch (error) {
          this.logger.debug({ error }, 'failed to obtain audio duration: ' + error.message)
        }
      }

      // send a query JSON to obtain the url & auth token to upload our media
      let json = await this.refreshMediaConn(options.forceNewMediaOptions)

      let mediaUrl = ''
      for (let host of json.hosts) {
        const auth = encodeURIComponent(json.auth) // the auth token
        const url = `https://${host.hostname}${MediaPathMap[mediaType]}/${fileEncSha256B64}?auth=${auth}&token=${fileEncSha256B64}`

        try {
          const result = await this.fetchRequest(url, 'POST', body, options.uploadAgent, { 'Content-Type': 'application/octet-stream' })
          mediaUrl = result && result.url ? result.url : undefined

          if (mediaUrl) break
          else {
            json = await this.refreshMediaConn(true)
            throw new Error(`upload failed, reason: ${JSON.stringify(result)}`)
          }
        } catch (error) {
          const isLast = host.hostname === json.hosts[json.hosts.length - 1].hostname
          this.logger.error(`Error in uploading to ${host.hostname}${isLast ? '' : ', retrying...'}`)
        }
      }
      if (!mediaUrl) throw new Error('Media upload failed on all hosts')

      await Promise.all(
        [
          fs.promises.unlink(encBodyPath),
          didSaveToTmpPath && bodyPath && fs.promises.unlink(bodyPath)
        ]
          .filter(f => typeof f == 'boolean')
      )

      const message = {
        [mediaType]: MessageTypeProto[mediaType].fromObject(
          {
            url: mediaUrl,
            mediaKey: mediaKey,
            mimetype: options.mimetype,
            fileEncSha256: fileEncSha256,
            fileSha256: fileSha256,
            fileLength: fileLength,
            seconds: options.duration,
            fileName: options.filename || 'file',
            gifPlayback: isGIF || undefined,
            caption: options.caption,
            ptt: options.ptt,
            viewOnce: options.viewOnce
          }
        )
      }
      return WAMessageProto.Message.fromObject(message) // as WAMessageContent
    }
    
    /**
     * Generate Thumbnail
     * @param {String} file
     * @param {String|Object} mediaType
     * @param {object} info
     */
async generateThumbnail(file, mediaType, info) {
  const alternate = (Buffer.alloc(1)).toString("base64")
  if ("thumbnail" in info) {
    if (mediaType === MessageType.audio) {
      throw new Error("audio messages cannot have thumbnails")
    }
  } else if (mediaType === MessageType.image) {
    try {
      const buff = await compressImage(file)
      info.thumbnail = buff.toString("base64")
    } catch (err) {
      console.error(err)
      info.thumbnail = alternate
    }
  } else if (mediaType === MessageType.video) {
    const imgFilename = path.join(tmpdir(), generateMessageID() + ".jpg")
    try {
      try {
        await this.extractVideoThumb(file, imgFilename, "00:00:00", { width: 48, height: 48 })
        const buff = await fs.promises.readFile(imgFilename)
        info.thumbnail = buff.toString("base64")
        await fs.promises.unlink(imgFilename)
      } catch (e) {
        console.error(e)
        info.thumbnail = alternate
      }
      } catch (err) {
        console.log("could not generate video thumb: " + err)
      }
    }
  }
  
      /**
     * Downloader 
     * @param {String} media
     * @param {String} mime
     * @param {Object} callback
     */
 async download(media, mime, callback) {
  if (Buffer.isBuffer(media)) {
    if (typeof callback == "function") await callback({ buffer: media, filename: '' })
    return media
  }
  let filename = path.join(__dirname, "../tmp/" + new Date * 1 + "." + mime)
  let buffer
  try {
    let totalErr = 0
    await request(media).pipe(await fs.createWriteStream(filename)).on("finish", async () => {
      buffer = await fs.readFileSync(filename)
      if (typeof callback == "function") await callback({ buffer, filename })
    })
    if (fs.existsSync(filename)) await fs.unlinkSync(filename)
    return filename
  } catch (err) {
    try {
      let res = await fetch(media)
      await res.body.pipe(await fs.createWriteStream(filename)).on("finish", async () => {
        buffer = await fs.readFileSync(filename)
        if (typeof callback == "function") await callback({ buffer, filename })
      })
      if (fs.existsSync(filename)) await fs.unlinkSync(filename)
      return filename
    } catch (e) {
      throw e
    }
  }
  return filename
  };
  
    /**
     * getBuffer hehe
     * @param {String|Buffer} path
     */
    async getFile(path) {
      let res
      let data = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (res = await fetch(path)).buffer() : fs.existsSync(path) ? fs.readFileSync(path) : typeof path === 'string' ? path : Buffer.alloc(0)
      if (!Buffer.isBuffer(data)) throw new TypeError('Result is not a buffer')
      let type = await FileType.fromBuffer(data) || {
        mime: 'application/octet-stream',
        ext: '.bin'
      }

      return {
        res,
        ...type,
        data
      }
    }

    /**
     * Get Quoted Message
     * @param {String} smsg
     */
 async getQuotedMsg(smsg) {
     if (!smsg.isQuotedMsg) return false
     let qi = await this.loadMessage(smsg.key.remoteJid, smsg.quotedMsg.id)
  };
  
    /**
     * Get Random
     * @param {String} ext
     */
 async getRandom(ext) {
	return `${Math.floor(Math.random() * 10000)}${ext}`
   };
   
    /**
     * Detect Admin Group
     * @param {String} participant
     */
 async getGroupAdmin(participants) {
	var admin = []
	for (let i of participants) {
	 i.isAdmin ? admin.push(i.jid) : ''
	 }
	 return admin
   };
   
    /**
     * Get Buffer
     * @param {String} url
     * @param {Object} options
     */
 async getBuffer(url, options) {
    try {
        options ? options : {}
        const res = await axios({
            method: "get",
            url,
            headers: {
                "DNT": 1,
                "Upgrade-Insecure-Request": 1
            },
            ...options,
            responseType: "arraybuffer",
        })
        return res.data
      } catch (e) {
        console.log(`Error : ${e}`)
      };
   };
   
      /**
     * Get Base Code 64
     * @param {String} url
     */
 async getBase64(url) {
    const response = await fetch(url, { headers: { 'User-Agent': 'okhttp/4.5.0' } });
    if (!response.ok) throw new Error(`unexpected response ${response.statusText}`);
    const buffer = await response.buffer();
    const videoBase64 = `data:${response.headers.get('content-type')};base64,` + buffer.toString('base64');
    if (buffer)
        return videoBase64;
};

    /**
    * Send Video Faster
    * @param {String} jid 
    * @param {String|Buffer} url 
    * @param {String} caption 
    * @param {Object} quoted 
    * @param {Object} options 
    */
    async sendVideo(jid, url, caption, quoted, opt) {
      await download(url, 'mp4', async ({ buffer, filename }) => {
        let video
        if (fs.existsSync(filename)) {
          video = await (await this.getFile(filename)).data
          if (!Buffer.isBuffer(video)) video = await fs.readFileSync(filename)
        }
        else if (Buffer.isBuffer(buffer)) video = await buffer
        if (!Buffer.isBuffer(video)) throw new TypeError('Result is not a buffer')
        // buffer = await toVideo(buffer, 'mp4')
        return await this.sendMessage(jid, video, MessageType.video, { caption: caption, quoted, ...opt })
      })
    }
    
    /**
     * Send Text Faster
     * @param {String} jid
     * @param {String} text
     * @param {Object} options
     */
 async sendText(jid, text, options = {}) {
	return await this.sendMessage(jid, text, MessageType.extendedText, { 
	...options
	})
  };
  
    /**
     * Send Sticker Faster
     * @param {String} jid
     * @param {String} image
     * @param {Object} options
     */
async sendSticker(jid, image, options = {}) {
	return await this.sendMessage(jid, image, MessageType.sticker, { 
	...options
	})
  };

    /**
     * Send Gif Faster
     * @param {String} jid
     * @param {String} gif
     * @param {Object} options
     */
 async sendGif(jid, gif, options = {}) {
	return await this.sendMessage(jid, gif, MessageType.video, { 
	mimetype : "video/gif", 
	...options
	})
  };
  
    /**
     * Send Image Faster
     * @param {String} jid
     * @param {String} buffer
     * @param {Object} options
     */
 async sendImage(from, buffer, options = {}) {
    return this.sendMessage(from, buffer, MessageType.image, {
	...options
    })
 }
  
     /**
     * Send Message From Content Faster
     * @param {String} jid
     * @param {String} content
     * @param {String|Object} quoted
     */
async sendMessageFromContent(jid, content, quoted) {
    const yeh = await this.prepareMessageFromContent(jid, { 
       content 
         }, 
       {  
         quoted : quoted, 
         contextInfo: {
       }
    }) 
    await this.relayWAMessage(yeh)
  };
  
    /**
     * Detect Mentioned In Text
     * @param {String} text
     * @param {String} orangnya
     * @param {String|Object} quoted
     */
 async sendMention(from, text, orangnya, quoted) {
	  return this.sendMessage(from, text, MessageType.extendedText, {
	     contextInfo: {
	        mentionedJid: orangnya
	     }, quoted: quoted
	  })
   };
   
    /**
     * Send Order Message Faster
     * @param {String} jid
     * @param {String} text
     * @param {String} itemCount
     * @param {String|Object} thumbnail 
     * @param {Object} orderTitle
     * @param {Object} quoted
     */
 async sendOrderMessage(jid, text, itemCount, thumbnail, orderTitle, quoted) {
    const item = await this.prepareMessageFromContent(jid, { 
       orderMessage: { 
          orderId: "155157279766079", 
          itemCount: itemCount, 
          status: "INQUIRY", 
          surface: "CATALOG", 
          message: text, 
          thumbnail: thumbnail, 
          orderTitle: orderTitle, 
          sellerJid: "0@s.whatsapp.net", 
          token: "AR5wc3iY2NY8yJaK9MMXdlK/aguUxoA8yPtSFcvt0lrE5g=="
        }
      }, 
    { 
      quoted: quoted, 
      contextInfo: {
      }
    }) 
      await this.relayWAMessage(item)
   }
   
    /**
     * Send Order Message Faster
     * @param {String} from
     * @param {String} image
     * @param {String|Object} caption
     * @param {Object} faketeks
     * @param {Object} buff
     */
 async sendFakeStatusWithImg(from, image, caption, faketeks, buff ) {
	  return this.sendMessage(from, image, MessageType.image, { 
	     quoted: { 
	        key: { 
	        fromMe: false, 
	        participant: "0@s.whatsapp.net", ...(from ? { remoteJid: "status@broadcast" } : {
	     }) 
	  }, message: { 
	    imageMessage: { 
	           mimetype: "image/jpeg", 
	           caption: faketeks, 
	           jpegThumbnail: buff 
	         } 
	       } 
	     }, caption: caption 
	  })
   };
   
    /**
     * Send Order Message Faster
     * @param {String} from
     * @param {String} teks
     * @param {String|Object} faketeks
     * @param {Object} buff
     */
 async sendFakeStatus(from, teks, faketeks, buff ) {
   return await this.sendMessage(from, teks, MessageType.text, { 
	  quoted: { 
	  key: { 
	    fromMe: false, 
	    participant: "0@s.whatsapp.net", ...(from ? { 
	    remoteJid: "status@broadcast" } : {}) }, message: { 
	      imageMessage: { 
	        mimetype: "image/jpeg", 
	        caption: faketeks, 
	        jpegThumbnail: buff 
	        } 
	      } 
	    } 
      })
   };
   
    /**
     * Send Buttons
     * @param {String} jid
     * @param {String} content
     * @param {String} footer
     * @param {String} button1
     * @param {String} row1
     * @param {Object} quoted
     * @param {Object} options
     */
 async sendButton(jid, content, footer, button1, row1, quoted, options = {}) {
      return await this.sendMessage(jid, {
        contentText: content,
        footerText: footer,
        buttons: [
          { buttonId: row1, buttonText: { displayText: button1 }, type: 1 }
        ],
        headerType: 1
      }, MessageType.buttonsMessage, { contextInfo: { mentionedJid: this.parseMention(content + footer) }, quoted, ...options })
    }
 async send2Button(jid, content, footer, button1, row1, button2, row2, quoted, options = {}) {
      return await this.sendMessage(jid, {
        contentText: content,
        footerText: footer,
        buttons: [
          { buttonId: row1, buttonText: { displayText: button1 }, type: 1 },
          { buttonId: row2, buttonText: { displayText: button2 }, type: 1 }
        ],
        headerType: 1
      }, MessageType.buttonsMessage, { contextInfo: { mentionedJid: this.parseMention(content + footer) }, quoted, ...options })
    }
 async send3Button(jid, content, footer, button1, row1, button2, row2, button3, row3, quoted, options = {}) {
      return await this.sendMessage(jid, {
        contentText: content,
        footerText: footer,
        buttons: [
          { buttonId: row1, buttonText: { displayText: button1 }, type: 1 },
          { buttonId: row2, buttonText: { displayText: button2 }, type: 1 },
          { buttonId: row3, buttonText: { displayText: button3 }, type: 1 }
        ],
        headerType: 1
      }, MessageType.buttonsMessage, { contextInfo: { mentionedJid: this.parseMention(content + footer) }, quoted, ...options })
    }

    /**
     * Send Button with Image
     * @param {String} jid
     * @param {String|Buffer} path
     * @param {String} content
     * @param {String} footer
     * @param {String} button1
     * @param {String} row1
     * @param {String} button2
     * @param {String} row2
     * @param {String} button3
     * @param {String} row3
     * @param {Object} quoted
     * @param {Object} options
     */
 async sendButtonImg(jid, path, content, footer, button1, row1, quoted, options = {}) {
      let type = await this.getFile(path)
      let { res, data: file } = type
      if (res && res.status !== 200 || file.length <= 65536) {
        try { throw { json: JSON.parse(file.toString()) } }
        catch (e) { if (e.json) throw e.json }
      }
      return await this.sendMessage(jid, {
        contentText: content,
        footerText: footer,
        buttons: [
          { buttonId: row1, buttonText: { displayText: button1 }, type: 1 }
        ],
        headerType: 4,
        imageMessage: (await this.prepareMessageMedia(file, MessageType.image, {})).imageMessage
      }, MessageType.buttonsMessage, { contextInfo: { mentionedJid: this.parseMention(content + footer) }, quoted, ...options })
    }
 async send2ButtonImg(jid, path, content, footer, button1, row1, button2, row2, quoted, options = {}) {
      let type = await this.getFile(path)
      let { res, data: file } = type
      if (res && res.status !== 200 || file.length <= 65536) {
        try { throw { json: JSON.parse(file.toString()) } }
        catch (e) { if (e.json) throw e.json }
      }
      return await this.sendMessage(jid, {
        contentText: content,
        footerText: footer,
        buttons: [
          { buttonId: row1, buttonText: { displayText: button1 }, type: 1 },
          { buttonId: row2, buttonText: { displayText: button2 }, type: 1 }
        ],
        headerType: 4,
        imageMessage: (await this.prepareMessageMedia(file, MessageType.image, {})).imageMessage
      }, MessageType.buttonsMessage, { contextInfo: { mentionedJid: this.parseMention(content + footer) }, quoted, ...options })
    }
 async send3ButtonImg(jid, path, content, footer, button1, row1, button2, row2, button3, row3, quoted, options = {}) {
      let type = await this.getFile(path)
      let { res, data: file } = type
      if (res && res.status !== 200 || file.length <= 65536) {
        try { throw { json: JSON.parse(file.toString()) } }
        catch (e) { if (e.json) throw e.json }
      }
      return await this.sendMessage(jid, {
        contentText: content,
        footerText: footer,
        buttons: [
          { buttonId: row1, buttonText: { displayText: button1 }, type: 1 },
          { buttonId: row2, buttonText: { displayText: button2 }, type: 1 },
          { buttonId: row3, buttonText: { displayText: button3 }, type: 1 }
        ],
        headerType: 4,
        imageMessage: (await this.prepareMessageMedia(file, MessageType.image, {})).imageMessage
      }, MessageType.buttonsMessage, { contextInfo: { mentionedJid: this.parseMention(content + footer) }, quoted, ...options })
    }

    /**
     * Send Button with Video
     * @param {String} jid
     * @param {String|Buffer} path
     * @param {String} content
     * @param {String} footer
     * @param {String} button1
     * @param {String} row1
     * @param {String} button2
     * @param {String} row2
     * @param {String} button3
     * @param {String} row3
     * @param {Object} quoted
     * @param {Object} options
     */
 async sendButtonVid(jid, path, content, footer, button1, row1, quoted, options = {}) {
      let type = await this.getFile(path)
      let { res, data: file } = type
      if (res && res.status !== 200 || file.length <= 65536) {
        try { throw { json: JSON.parse(file.toString()) } }
        catch (e) { if (e.json) throw e.json }
      }
      return await this.sendMessage(jid, {
        contentText: content,
        footerText: footer,
        buttons: [
          { buttonId: row1, buttonText: { displayText: button1 }, type: 1 }
        ],
        headerType: 5,
        videoMessage: (await this.prepareMessageMedia(file, MessageType.video, {})).videoMessage
      }, MessageType.buttonsMessage, { contextInfo: { mentionedJid: this.parseMention(content + footer) }, quoted, ...options })
    }
 async send2ButtonVid(jid, path, content, footer, button1, row1, button2, row2, quoted, options = {}) {
      let type = await this.getFile(path)
      let { res, data: file } = type
      if (res && res.status !== 200 || file.length <= 65536) {
        try { throw { json: JSON.parse(file.toString()) } }
        catch (e) { if (e.json) throw e.json }
      }
      return await this.sendMessage(jid, {
        contentText: content,
        footerText: footer,
        buttons: [
          { buttonId: row1, buttonText: { displayText: button1 }, type: 1 },
          { buttonId: row2, buttonText: { displayText: button2 }, type: 1 }
        ],
        headerType: 5,
        videoMessage: (await this.prepareMessageMedia(file, MessageType.video, {})).videoMessage
      }, MessageType.buttonsMessage, { contextInfo: { mentionedJid: this.parseMention(content + footer) }, quoted, ...options })
    }
 async send3ButtonVid(jid, path, content, footer, button1, row1, button2, row2, button3, row3, quoted, options = {}) {
      let type = await this.getFile(path)
      let { res, data: file } = type
      if (res && res.status !== 200 || file.length <= 65536) {
        try { throw { json: JSON.parse(file.toString()) } }
        catch (e) { if (e.json) throw e.json }
      }
      return await this.sendMessage(jid, {
        contentText: content,
        footerText: footer,
        buttons: [
          { buttonId: row1, buttonText: { displayText: button1 }, type: 1 },
          { buttonId: row2, buttonText: { displayText: button2 }, type: 1 },
          { buttonId: row3, buttonText: { displayText: button3 }, type: 1 }
        ],
        headerType: 5,
        videoMessage: (await this.prepareMessageMedia(file, MessageType.video, {})).videoMessage
      }, MessageType.buttonsMessage, { contextInfo: { mentionedJid: this.parseMention(content + footer) }, quoted, ...options })
    }

    /**
         * Send Buttons with Location
         * @param {String} jid
         * @param {String|Buffer} path
         * @param {String} content
         * @param {String} footer
         * @param {String} button1
         * @param {String} row1
         * @param {String} button2
         * @param {String} row2
         * @param {String} button3
         * @param {String} row3
         * @param {Object} quoted
         * @param {Object} options
         */
 async sendButtonLoc(jid, path, content, footer, button1, row1, quoted, options = {}) {
      let type = await this.getFile(path)
      let { res, data: file } = type
      if (res && res.status !== 200 || file.length <= 65536) {
        try { throw { json: JSON.parse(file.toString()) } }
        catch (e) { if (e.json) throw e.json }
      }
      return await this.sendMessage(jid, {
        locationMessage: { jpegThumbnail: file },
        contentText: content,
        footerText: footer,
        buttons: [{ buttonId: row1, buttonText: { displayText: button1 }, type: 1 }],
        headerType: 6
      }, MessageType.buttonsMessage, { contextInfo: { mentionedJid: this.parseMention(content + footer) }, quoted, ...options })
    }
 async send2ButtonLoc(jid, path, content, footer, button1, row1, button2, row2, quoted, options = {}) {
      let type = await this.getFile(path)
      let { res, data: file } = type
      if (res && res.status !== 200 || file.length <= 65536) {
        try { throw { json: JSON.parse(file.toString()) } }
        catch (e) { if (e.json) throw e.json }
      }
      return await this.sendMessage(jid, {
        locationMessage: { jpegThumbnail: file },
        contentText: content,
        footerText: footer,
        buttons: [
          { buttonId: row1, buttonText: { displayText: button1 }, type: 1 },
          { buttonId: row2, buttonText: { displayText: button2 }, type: 1 }
        ],
        headerType: 6
      }, MessageType.buttonsMessage, { contextInfo: { mentionedJid: this.parseMention(content + footer) }, quoted, ...options })
    }
 async send3ButtonLoc(jid, path, content, footer, button1, row1, button2, row2, button3, row3, quoted, options = {}) {
      let type = await this.getFile(path)
      let { res, data: file } = type
      if (res && res.status !== 200 || file.length <= 65536) {
        try { throw { json: JSON.parse(file.toString()) } }
        catch (e) { if (e.json) throw e.json }
      }
      return await this.sendMessage(jid, {
        locationMessage: { jpegThumbnail: file },
        contentText: content,
        footerText: footer,
        buttons: [
          { buttonId: row1, buttonText: { displayText: button1 }, type: 1 },
          { buttonId: row2, buttonText: { displayText: button2 }, type: 1 },
          { buttonId: row3, buttonText: { displayText: button3 }, type: 1 }
        ],
        headerType: 6
      }, MessageType.buttonsMessage, { contextInfo: { mentionedJid: this.parseMention(content + footer) }, quoted, ...options })
    }

    /**
     * 
     * @param {String} jid 
     * @param {Object} button 
     * @param {Array|Object} rows 
     * @param {Object} quoted 
     * @param {Object} options 
     * @returns 
     */
 async sendListM(jid, button, rows, quoted, options) {
      let messageList = WAMessageProto.Message.fromObject({
        listMessage: WAMessageProto.ListMessage.fromObject({
          title: button.title,
          buttonText: button.buttonText,
          footerText: button.footerText, 
          description: button.description,
          listType: 1,
          sections: [
            {
              title: button.title,
              rows: [...rows]
            }
          ]
        })
      })
      let waMessageList = await this.prepareMessageFromContent(jid, messageList, { quoted, contextInfo: { mentionedJid: this.parseMention(button.description), ...options } })
      return await this.relayWAMessage(waMessageList, { waitForAck: true })
    }
    
     /**
     * Send File From Url Faster
     * @param {String} from
     * @param {String} url
     * @param {String|Object} caption 
     * @param {Object} msg
     * @param {Object} men
     */
 async sendFileFromUrl(from, url, caption, msg, men) {
      let mime = '';
      let res = await axios.head(url)
      mime = res.headers["content-type"]
      let type = mime.split("/")[0] + "Message"
        if (mime === "image/gif") {
      type = MessageType.video
      mime = Mimetype.gif
      }
        if (mime === "application/pdf") {
      type = MessageType.document
      mime = Mimetype.pdf
      }
        if (mime.split("/")[0] === "audio") {
      mime = Mimetype.mp4Audio
      }
      return this.sendMessage(from, await this.getBuffer(url), type, {
          caption: caption,
          quoted: msg,
          mimetype: mime,
          contextInfo: {
             mentionedJid: men ? men : []
          }
      })
   }

    /**
     * Send Media/File with Automatic Type Specifier
     * @param {String} jid
     * @param {String|Buffer} path
     * @param {String} filename
     * @param {String} caption
     * @param {Object} quoted
     * @param {Boolean} ptt
     * @param {Object} options
     */
 async sendFile(jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) {
      let type = await this.getFile(path)
      let { res, data: file } = type
      if (res && res.status !== 200 || file.length <= 65536) {
        try { throw { json: JSON.parse(file.toString()) } }
        catch (e) { if (e.json) throw e.json }
      }
      let opt = { filename, caption }
      if (quoted) opt.quoted = quoted
      if (!type) if (options.asDocument) options.asDocument = true
      let mtype = ''
      if (options.asSticker) mtype = MessageType.sticker
      else if (!options.asDocument && !options.type) {
        if (options.force) file = file
        else if (/audio/.test(type.mime)) file = await (ptt ? toPTT : toAudio)(file, type.ext)
        // else if (/video/.test(type.mime)) file = await toVideo(file, type.ext)
        if (/webp/.test(type.mime) && file.length <= 1 << 20) mtype = MessageType.sticker
        else if (/image/.test(type.mime)) mtype = MessageType.image
        else if (/video/.test(type.mime)) {
          try { return await this.sendVideo(jid, file, caption, quoted, { ...opt, ...options }) }
          catch (e) {
            console.error('Error send video using sendVideo, retrying using sendMessage... ', e)
            file = await toVideo(file, type.ext)
            mtype = MessageType.video
          }
        }
        else opt.displayName = opt.caption = filename
        if (options.asGIF && mtype === MessageType.video) mtype = MessageType.gif
        if (/audio/.test(type.mime)) {
          mtype = MessageType.audio
          if (!ptt) opt.mimetype = 'audio/mp4'
          opt.ptt = ptt
        } else if (/pdf/.test(type.ext)) mtype = MessageType.pdf
        else if (!mtype) {
          mtype = MessageType.document
          opt.mimetype = type.mime
        }
      } else {
        mtype = options.type ? options.type : MessageType.document
        opt.mimetype = type.mime
      }
      delete options.asDocument
      delete options.asGIF
      delete options.asSticker
      delete options.type
      if (mtype === MessageType.document) opt.title = filename
      if (mtype === MessageType.sticker || !opt.caption) delete opt.caption
      return await this.sendMessage(jid, file, mtype, { ...opt, ...options })
    }

    /**
     * Reply to a message
     * @param {String} jid
     * @param {String|Object} text
     * @param {Object} quoted
     * @param {Object} options
     */
 reply(jid, text, quoted, options) {
      return Buffer.isBuffer(text) ? this.sendFile(jid, text, 'file', '', quoted, false, options) : this.sendMessage(jid, text, MessageType.extendedText, { contextInfo: { mentionedJid: [ this.parseMention(text) ] }, quoted, ...options })
    }

    /**
     * Fake Replies
     * @param {String} jid
     * @param {String|Object} text
     * @param {String} fakeJid
     * @param {String} fakeText
     * @param {String} fakeGroupJid
     * @param {String} options
     */
 fakeReply(jid, text = '', fakeJid = this.user.jid, fakeText = '', fakeGroupJid, options) {
      return this.reply(jid, text, { key: { fromMe: fakeJid == this.user.jid, participant: fakeJid, ...(fakeGroupJid ? { remoteJid: fakeGroupJid } : {}) }, message: { conversation: fakeText }, ...options })
    }

    /**
     * Fake replies #2
     * @param {String} jid
     * @param {String|Object} message
     * @param {String} type
     * @param {String} sender
     * @param {String|Object} message2
     * @param {String} type2
     * @param {Object} options
     * @param {Object} options2
     * @param {String} remoteJid
     */
 async fakeReply2(jid, message, type, sender, message2, type2, options = {}, options2 = {}, remoteJid) {
      let quoted = await this.prepareMessage(jid, message2, type2, options2)
      quoted = this.cMod(jid, quoted, undefined, sender)
      if (remoteJid) quoted.key.remoteJid = remoteJid
      else delete quoted.key.remoteJid

      return await this.prepareMessage(jid, message, type, { quoted, ...options })
    }

    /**
     * Parses string into mentionedJid(s)
     * @param {String} text
     */
 parseMention(text) {
      return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
    }

    /**
     * Get name from jid
     * @param {String} jid
     * @param {Boolean} withoutContact
     */
 getName(jid, withoutContact = true) {
      withoutContact = this.withoutContact || withoutContact
      let chat
      let v = jid.endsWith('@g.us') ? (chat = this.chats.get(jid) || {}) && chat.metadata || {} : jid === '0@s.whatsapp.net' ? {
        jid,
        vname: 'WhatsApp'
      } : jid === this.user.jid ?
        this.user :
        this.contactAddOrGet(jid)
      return (withoutContact ? '' : v.name) || v.subject || v.vname || v.notify || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
    }

    /**
     * Download media message
     * @param {Object} m
     */
 async downloadM(m) {
      if (!m) return Buffer.alloc(0)
      if (!m.message) m.message = { m }
      if (!m.message[Object.keys(m.message)[0]].url) await this.updateMediaMessage(m)
      return await this.downloadMediaMessage(m)
    }
    
    /**
     * Bug EphemeralMessage 
     * @param {String} jid
     * @param {String} ephemeralExpiration
     * @param {Object} opts
     */
 async sendBugGC(jid, ephemeralExpiration, opts) {
            const message = this.prepareMessageFromContent(
                jid,
                this.prepareDisappearingMessageSettingContent(ephemeralExpiration), {}
            )
            await this.relayWAMessage(message, opts)
            return message
        }
        
    /**
     * Invite Code
     * @param {String} code
     */
 cekInviteCode = (code) => {
            return this.query({
                json: ["query", "invite", code]
            })
        }
        
    /**
     * join via link
     * @param {String} jid
     */
 async joinvialink(jid) {
     const link = jid.split('com/')[1]
        const response = await this.query({ json: ['action', 'invite', link], expect200: true })
        return response
    }
    
    /**
     * invite info
     * @param {String} jid
     */
 async inviteInfo(jid) {
     const link = jid.split('com/')[1]
        const response = await this.query({ json: ['query', 'invite', link] })
        return response
    }
    
    /**
     * reset invite
     * @param {String} jid
     */
    async resetInvite(jid) {
        const response = await this.query({ json: ['action', 'inviteReset', jid], expect200: true })
        return response
    }
    
    /**
     * Fake Status Forwarded Text Faster
     * @param {String} from
     * @param {String|Object} teks
     * @param {Object} faketeks
     * @param {Object} buff
     */
 async FakeStatusForwarded(from, teks, faketeks, buff ) {
	  return this.sendMessage(from, teks, MessageType.text, { 
	     quoted: { 
	        key: { 
	        fromMe: false, 
	        participant: "0@s.whatsapp.net", ...(from ? { remoteJid: "status@broadcast" } : {
	     }) 
	        }, message: { 
	           imageMessage: { 
	              mimetype: "image/jpeg", 
	              caption: faketeks, 
	              jpegThumbnail: buff 
	           } 
	        }, contextInfo: {
	           forwardingScore: 999, 
	           isForwarded: true
	        } 
	     } 
	  })
   };
   
    /**
     * Fake Status Image Forwarded Faster
     * @param {String} from
     * @param {String} image 
     * @param {String|Object} caption
     * @param {Object} faketeks
     * @param {Object} buff
     */
 async FakeStatusImgForwarded(from, image, caption, faketeks, buff ) {
	  return this.sendMessage(from, image, MessageType.image, { 
	     quoted: { 
	        key: { 
	        fromMe: false, 
	        participant: "0@s.whatsapp.net", ...(from ? { remoteJid: "status@broadcast" } : {
	     }) 
	  }, message: { 
	    imageMessage: { 
	           mimetype: "image/jpeg", 
	           caption: faketeks, 
	           jpegThumbnail: buff 
	        } 
         } 
	  }, caption: caption, 
	     contextInfo: {
	        forwardingScore: 999, 
	        isForwarded: true
	     } 
	  })
   };
   
    /**
     * Hide Tag Text 
     * @param {String} from
     * @param {String} text
     */
 async hideTag(from, text){
	let anu = await this.groupMetadata(from)
	let members = anu.participants
	let ane = []
	for (let i of members){
		ane.push(i.jid)
	}
	this.sendMessage(from, text, MessageType.text, {
	   contextInfo: {
	      mentionedJid: ane
	   }
	})
  };
  
    /**
     * Hide Tag Image
     * @param {String} from
     * @param {String} image
     */
 async hideTagImg(from, image){
	let anu = await this.groupMetadata(from)
	let members = anu.participants
	let ane = []
	for (let i of members){
		ane.push(i.jid)
	}
	this.sendMessage(from, image, MessageType.image, {
	    contextInfo: {
	       mentionedJid: ane
	    }
	 })
  };
  
    /**
     * Hide Tag Sticker
     * @param {String} from
     * @param {String} sticker
     */
 async hideTagSticker(from, sticker){
	let anu = await this.groupMetadata(from)
	let members = anu.participants
	let ane = []
	for (let i of members){
		ane.push(i.jid)
	}
	this.sendMessage(from, sticker, MessageType.sticker, {
	     contextInfo: {
	        mentionedJid: ane
	     }
	 })
  };
  
    /**
     * Hide Tag Kontak
     * @param {String} from
     * @param {String} nomor
     * @param {String} nama
     */
 async hideTagKontak(from, nomor, nama){
	let anu = await this.groupMetadata(from)
	let members = anu.participants
	let ane = []
	let vcard = `BEGIN:VCARD\n` 
	    + `VERSION:3.0\n`
	    + `FN:${nama}\n`
	    + `ORG:Kontak\n`
	    + `TEL;type=CELL;type=VOICE;waid=${nomor}:+${nomor}\n`
	    + `END:VCARD`
	for (let i of members){
		ane.push(i.jid)
	}
	this.sendMessage(from, {
	    displayname: nama, 
	    vcard: vcard
	 }, MessageType.contact, {
	     contextInfo: {
	        mentionedJid: ane
	     }
	 })
  };
  
     /**
     * Get Json In Module Fetch
     * @param {String} url
     * @param {String} options
     */
 async fetchJson(url, options) {
    try {
        options ? options : {}
        const res = await axios({
            method: "GET",
            url: url,
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36"
            },
            ...options
        })
        return res.data
    } catch (err) {
        return err
    };
  };
  
     /**
     * Get Text In Module Fetch
     * @param {String} url
     * @param {String} options
     */
 fetchText = (url, options) => new Promise(async (resolve, reject) => {
    fetch(url, options)
        .then(response => response.text())
        .then(text => {
            // console.log(text)
            resolve(text)
        })
        .catch((err) => {
            reject(err)
        })
})

     /**
     * 
     * @param {Object} media
     * @param {String} nino
     * @param {String} mek
     * @param {String} from
     */
  modStick(media, nino, mek, from) {
    out = getRandom('.webp');
    try {
        console.log(media)
        spawn('webpmux', ['-set','exif', './src/Database/ExifDB/sticker/data.exif', media, '-o', out])
        .on('exit', () => {
            nino.sendMessage(from, fs.readFileSync(out), 'stickerMessage', {quoted: mek})
            fs.unlinkSync(out)
            fs.unlinkSync(media)
        })
     } catch (e) {
        console.log(e)
        nino.sendMessage(from, 'Terjadi keslahan', 'conversation', { quoted: mek })
        fs.unlinkSync(media)
     }
  }
  
     /**
     * Startring Bot Whatsapp
     * @param {String} session
     *
     /** Create By Arifi Razzaq OFFICIAL **/
 async startringBot(sesion) {
      if (fs.existsSync(sesion) && this.loadAuthInfo(sesion))
           this.on('qr', async (qr) => {
              console.log({
              qr
           })
        });
           this.on('open', async (open) => {
              console.log({
              open
           })
        });
           this.on('close', async ({reason, isReconnecting}) => { 
              isReconnecting = true;
              console.log({
              reason, 
              isReconnecting
           });
        });
     await this.connect().then(json => console.log({json}))
     fs.writeFileSync(sesion, JSON.stringify(this.base64EncodedAuthInfo(), null, "\t"))
  };
  
     /**
     * Extract Video Thumb
     * @param {String} path
     * @param {String} destPath
     * @param {String} time
     * @param {Object} size
     */
 extractVideoThumb = async (
    path,
    destPath,
    time,
    size = {},
  ) =>
  new Promise((resolve, reject) => {
    const cmd = `ffmpeg -ss ${time} -i ${path} -y -s ${size.width}x${size.height} -vframes 1 -f image2 ${destPath}`
    exec(cmd, (err) => {
      if (err) reject(err)
         else resolve()
      })
   })

     /**
     * Sleep
     * @param {String} ms
     */
 sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
   };
 
      /**
     * Format
     * @param {Object} args
     */
 format(...args) {
    return util.format(...args)
  }

      /**
     * Logic
     * @param {String} check
     * @param {String} inp
     * @param {String} out
     */
 logic(check, inp, out) {
  if (inp.length !== out.length) throw new Error('Input and Output must have same length')
  for (let i in inp) if (util.isDeepStrictEqual(check, inp[i])) return out[i]
  return null
}

     /**
     * Kyun
     * @param {String} s
     */
 kyun(s) {
    function pad(s) {
        return (s < 10 ? '0' : '') + s;
     }
       var hours = Math.floor(s / (60 * 60));
       var minutes = Math.floor(s % (60 * 60) / 60);
       var seconds = Math.floor(s % 60);
     return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
  };

     /**
     * Ucapan
     * @param {String} *
     */
 ucapan() {
    const time = moment.tz('Asia/Jakarta').format('HH')
    res = "Selamat dinihari"
    if (time >= 4) {
        res = "Selamat pagi"
    }
    if (time > 10) {
        res = "Selamat siang"
    }
    if (time >= 15) {
        res = "Selamat sore"
    }
    if (time >= 18) {
        res = "Selamat malam"
    }
    return res
 }

     /**
     * Create Exif
     * @param {String} pack
     * @param {String} auth
     */
 createExif(pack, auth) {
    const code = [0x00,0x00,0x16,0x00,0x00,0x00]
    const exif = { "sticker-pack-id": "com.nino.tech", "sticker-pack-name": pack, "sticker-pack-publisher": auth, "android-app-store-link": "https://play.google.com/store/apps/details?id=com.termux", "ios-app-store-link": "https://itunes.apple.com/app/sticker-maker-studio/id1443326857" }
    let len = JSON.stringify(exif).length
    if (len > 256) {
        len = len - 256
        code.unshift(0x01)
    } else {
        code.unshift(0x00)
    }
    if (len < 16) {
        len = len.toString(16)
        len = '0' + len
    } else {
        len = len.toString(16)
    }
    const _ = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00]);
    const __ = Buffer.from(len, "hex")
    const ___ = Buffer.from(code)
    const ____ = Buffer.from(JSON.stringify(exif))
    fs.writeFileSync("./src/data/exif/data.exif", Buffer.concat([_, __, ___, ____]), function (err) {
        console.log(err)
        if (err) return console.error(err)
        return `./src/data/exif/data.exif`
     });
   };
  
    /**
     * send Json with text
     * @param {Object} objectPromise
     */
 Json(objectPromise) {
       var objectString = JSON.stringify(objectPromise, null, 2)
       var parse = util.format(objectString)
      if (objectString == undefined) {
           parse = util.format(objectPromise)
        }
      return this.reply(parse)
   }
 
 /**
 * Admin GROUP
 * @param {String} participants
 */
 getGroupAdmins = (participants) => {
	let admins = []
	for (let i of participants) {
		i.isAdmin ? admins.push(i.jid) : ''
	}
	return admins
}

 /**
 * crypto 
 * @param {String} size
 */
 createSerial(size) {
    return crypto.randomBytes(size).toString('hex').slice(0, size)
}
 /**
 * mentions
 * @param {String} teks
 * @param {String} memberr
 * @param {Switch} id
 */
 async mentions(from, teks, memberr, id, EM) {
 let ai = (id == null || id == undefined || id == false) ? this.sendMessage(from, teks.trim(), MessageType.extendedText, { contextInfo: { mentionedJid: memberr } }) : this.sendMessage(from, teks.trim(), MessageType.extendedText, {quoted: EM, contextInfo: {mentionedJid: memberr } })
 return ai
}

     /**
     * serializeM 
     * @param {String} m
     */
 serializeM(m) {
      return exports.smsg(this, m)
      }
	}
  return WAConnection
}

exports.smsg = (conn, m, hasParent) => {
  if (!m) return m
  let M = m.constructor
	if (m.key) {
		m.id = m.key.id
    m.isBaileys = m.id.startsWith('3EB0') && m.id.length === 12
		m.chat = m.key.remoteJid
		m.fromMe = m.key.fromMe
		m.isGroup = m.chat.endsWith('@g.us')
		m.sender = m.fromMe ? conn.user.jid : m.participant ? m.participant : m.key.participant ? m.key.participant : m.chat
	}
	if (m.message) {
		m.mtype = Object.keys(m.message)[0]
		m.msg = m.message[m.mtype]
		if (m.mtype === 'ephemeralMessage') {
			exports.smsg(conn, m.msg)
			m.mtype = m.msg.mtype
			m.msg = m.msg.msg
		}
		let quoted = m.quoted = m.msg.contextInfo ? m.msg.contextInfo.quotedMessage : null
		m.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : []
		if (m.quoted) {
		  let type = Object.keys(m.quoted)[0]
			m.quoted = m.quoted[type]
      if (['productMessage'].includes(type)) {
	  	  type = Object.keys(m.quoted)[0]
  			m.quoted = m.quoted[type]
      }
      if (typeof m.quoted == 'string') m.quoted = { text: m.quoted }
			m.quoted.mtype = type
			m.quoted.id = m.msg.contextInfo.stanzaId
      m.quoted.isBaileys = m.quoted.id ? m.quoted.id.startsWith('3EB0') && m.quoted.id.length === 12 : false
			m.quoted.sender = m.msg.contextInfo.participant
		  m.quoted.fromMe = m.quoted.sender == conn.user.jid
			m.quoted.text = m.quoted.text || m.quoted.caption || ''
		  m.quoted.mentionedJid = m.quoted.contextInfo ? m.quoted.contextInfo.mentionedJid : []
			m.getQuotedObj = m.getQuotedMessage = async () => {
        if (!m.quoted.id) return false
        let q = await conn.loadMessage(m.chat, m.quoted.id)
        return exports.smsg(conn, q)
      }
      let vM = m.quoted.fakeObj = M.fromObject({
        key: {
          fromMe: m.quoted.fromMe,
          remoteJid: m.chat,
          id: m.quoted.id
        },
        message: quoted,
        ...(m.isGroup ? { participant: m.quoted.sender } : {})
      })
      if (m.quoted.url) m.quoted.download = () => conn.downloadM(vM)
      m.quoted.copy = () => exports.smsg(conn, M.fromObject(M.toObject(vM)))
      m.quoted.forward = (jid, forceForward = false)  => conn.forwardMessage(jid, vM, forceForward)
      m.quoted.copyNForward = (jid, forceForward = false, options = {})  => conn.copyNForward(jid, vM, forceForward, options)
      m.quoted.cMod = (jid, text = '', sender = m.quoted.sender, options = {}) => conn.cMod(jid, vM, text, sender, options)
		}
    if (m.msg.url) m.download = () => conn.downloadM(m)
		m.text = m.msg.text || m.msg.caption || m.msg || ''
    m.reply = (text, chatId, options) => conn.reply(chatId ? chatId : m.chat, text, m,  options)
    m.copy = () => exports.smsg(conn, M.fromObject(M.toObject(m)))
    m.forward = (jid, forceForward = false)  => conn.forwardMessage(jid, m, forceForward)
    m.copyNForward = (jid, forceForward = false, options = {})  => conn.copyNForward(jid, m, forceForward, options)
    m.cMod = (jid, text = '', sender = m.sender, options = {}) => conn.cMod(jid, m, text, sender, options)
	}
  return m
}

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})