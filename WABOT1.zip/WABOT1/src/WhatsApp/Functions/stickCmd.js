"use strict";
require("dotenv").config();
const {modul} = require("../Validator/Config");
const {fs, chalk} = modul;

const _scommand = JSON.parse(fs.readFileSync('./src/Database/JsonDB/stickercmd/scommand.json'));

const addCmd = (id, command) => {
const obj = { id: id, chats: command }
             _scommand.push(obj)
             fs.writeFileSync('./src/Database/JsonDB/stickercmd/scommand.json', JSON.stringify(_scommand))
         }
         
const getCommandPosition = (id) => {
      let position = null
         Object.keys(_scommand).forEach((i) => {
            if (_scommand[i].id === id) {
               position = i
            }
        })
     if (position !== null) {
     return position
     }
  }
  
const getCmd = (id) => {
      let position = null
         Object.keys(_scommand).forEach((i) => {
            if (_scommand[i].id === id) {
               position = i
            }
        })
     if (position !== null) {
     return _scommand[position].chats
     }
  }
  
const checkscommand = (id) => {
      let status = false
         Object.keys(_scommand).forEach((i) => {
            if (_scommand[i].id === id) {
              let status = true
           }
        })
     return status
  }
 
module.exports = { 
 _scommand, 
 addCmd, 
 getCommandPosition, 
 checkscommand, 
 getCmd
}

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})