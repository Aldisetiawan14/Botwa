"use strict";
require("dotenv").config();
require("../../../src/Database/JsDB/JSON.js");
const {modul, infos} = require("../Validator/Config");
const {welcome, leave} = require("../Validator/Catatan");
const {fs, chalk} = modul;
const {owner} = infos;

const GroupModules = async (rojak, json) => {
try {
    const gcdata = await rojak.groupMetadata(json.jid)
    const pkgg = require('../../../package.json');
    const numur = json.participants[0]
    const isWelcome = welkom.includes(json.jid)
    if (!isWelcome) return
    let fkontak = { 
        key: { 
        fromMe: false, 
        participant: `0@s.whatsapp.net`, ...(json.jid ? { 
        remoteJid: '6283136505591-1604595598@g.us' } : {}
    )}, message: { 
        "contactMessage": {
        "displayName": `${gcdata.subject}`,
        "vcard": `BEGIN:VCARD\n`
        + `VERSION:3.0\n`
        + `N:2;${pkgg.author};;;\n`
        + `FN:${pkgg.version}\n`
        + `item1.TEL;waid=${owner[0]}:+${owner[0]}\n`
        + `item1.X-ABLabel:Mobile\n`
        + `END:VCARD` 
        }
      }
    }
    
if (json.action == 'add') {
    await rojak.sendText(gcdata.id, welcome(numur.split('@')[0], gcdata.subject), { 
        "contextInfo": { 
           mentionedJid: [numur]}, 
           quoted: fkontak
        })
} else if (json.action == 'remove') {
    await rojak.sendText(gcdata.id, leave(numur.split('@')[0], gcdata.subject), { 
        "contextInfo": { 
           mentionedJid: [numur]}, 
           quoted: fkontak
        })
    } 
 } catch (err) {
   console.log({err})
 }
}

module.exports = { GroupModules }  

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})