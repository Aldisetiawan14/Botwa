"use strict";
require("dotenv").config();
const {modul} = require("../Validator/Config");
const {fs, chalk} = modul;

module.exports = {
    async batteryAsyncOBB(rojak, json) {
     try {
         rojak.charging = [];
         rojak.cc = [];
         rojak.battrey = { value: 0, cas: true ? "charging" : '' }
         rojak.battrey.value = json[2][0][1].value
         rojak.battrey.cas = json[2][0][1].live
           if (parseInt(json[2][0][1].value) <= 1) {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [▒▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '1') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [▒▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '2') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [▒▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '3') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [▒▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '4') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [▒▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '5') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [▒▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '6') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [▒▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '7') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [▒▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '8') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [▒▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '9') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [▒▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '10') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '11') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '12') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '13') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '14') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '15') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '16') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '17') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '18') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '19') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█▒▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '20') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '21') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '22') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '23') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '24') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '25') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '26') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '27') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '28') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '29') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██▒▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '30') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '31') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '32') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '33') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '34') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '35') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '36') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '37') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '38') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '39') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███▒▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '40') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '41') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '42') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '43') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '44') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '45') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '46') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '46') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '48') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '49') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████▒▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '50') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '51') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '52') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '53') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '54') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '55') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '56') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '57') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '58') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '59') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████▒▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '60') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██████▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '61') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██████▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '62') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██████▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '63') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██████▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '64') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██████▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '65') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██████▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '66') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██████▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '67') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██████▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '68') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██████▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '69') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██████▒▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '70') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███████▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '71') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███████▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '72') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███████▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '73') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███████▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '74') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███████▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '75') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███████▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '76') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███████▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '77') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███████▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '78') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███████▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '79') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [███████▒▒▒]`
              } else if (parseInt(json[2][0][1].value) == '80') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████████▒▒]`
              } else if (parseInt(json[2][0][1].value) == '81') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████████▒▒]`
              } else if (parseInt(json[2][0][1].value) == '82') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████████▒▒]`
              } else if (parseInt(json[2][0][1].value) == '83') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████████▒▒]`
              } else if (parseInt(json[2][0][1].value) == '84') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████████▒▒]`
              } else if (parseInt(json[2][0][1].value) == '85') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████████▒▒]`
              } else if (parseInt(json[2][0][1].value) == '85') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████████▒▒]`
              } else if (parseInt(json[2][0][1].value) == '87') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████████▒▒]`
              } else if (parseInt(json[2][0][1].value) == '88') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████████▒▒]`
              } else if (parseInt(json[2][0][1].value) == '89') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████████▒▒]`
              } else if (parseInt(json[2][0][1].value) == '90') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [████████▒▒]`
              } else if (parseInt(json[2][0][1].value) == '91') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████████▒]`
              } else if (parseInt(json[2][0][1].value) == '92') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████████▒]`
              } else if (parseInt(json[2][0][1].value) == '93') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████████▒]`
              } else if (parseInt(json[2][0][1].value) == '94') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████████▒]`
              } else if (parseInt(json[2][0][1].value) == '95') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████████▒]`
              } else if (parseInt(json[2][0][1].value) == '96') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████████▒]`
              } else if (parseInt(json[2][0][1].value) == '97') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████████▒]`
              } else if (parseInt(json[2][0][1].value) == '98') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████████▒]`
              } else if (parseInt(json[2][0][1].value) == '99') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [█████████▒]`
              } else if (parseInt(json[2][0][1].value) == '100') {
                rojak.cc = `${parseInt(json[2][0][1].value)}% [██████████]`
              }
          if (parseInt(json[2][0][1].value) == '50'){
          if (json[2][0][1].live == 'true') rojak.charging = true;
          if (json[2][0][1].live == 'false') rojak.charging = false;
          }
          let battery = rojak.cc
            console.log({ battery, json });
          } catch (err) {
            console.log({err}) 
          }
       }
    }

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})