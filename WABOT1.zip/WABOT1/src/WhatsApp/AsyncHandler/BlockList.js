"use strict";
require("dotenv").config();
const {modul} = require("../Validator/Config");
const {fs, chalk} = modul;

module.exports = {
    async listBlockked(rojak, json) {
     try {
      rojak.blocked = [];
       if (rojak.blocked.length > 2) return
           for (let i of json[1].blocklist) {
                 rojak.blocked.push(i.replace('c.us', 's.whatsapp.net'))
              }
           } catch (err) {
             console.log(err)
           }
         }
       }

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})