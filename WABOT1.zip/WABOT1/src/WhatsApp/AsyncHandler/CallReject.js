"use strict";
require("dotenv").config();
const {modul, infos} = require("../Validator/Config");
const {callText} = require("../Validator/Catatan");
const {chalk, baileys, fs} = modul;
const {MessageType} = baileys;
const {owner} = infos;

module.exports = {
    async rejectPhone(rojak, json) {
        try {
        let number = json[1]['from'];
        let isOffer = json[1]["type"] == "offer";
        if (number && isOffer && json[1]["data"]) {
            var tag = rojak.generateMessageTag();
            var NodePayload = ["action", "call", ["call", {
                    "from": rojak.user.jid,
                    "to": number.split("@")[0] + "@s.whatsapp.net",
                    "id": tag
               },
                [
                    ["reject", {
                        "call-id": json[1]['id'],
                        "call-creator": number.split("@")[0] + "@s.whatsapp.net",
                        "count": "0"
                   }, null]
                ]
            ]];
            await console.log({tag, NodePayload})
            await rojak.send(`${tag}, ${JSON.stringify(NodePayload)}`)
            await rojak.sendMessage(number, callText(), MessageType.text, {sendEphemeral: true})
            await new Promise(resolve => setTimeout(resolve, 4000));
            await rojak.blockUser(number, "add") // Block user
            await console.log(chalk.hex('#FF8C00')('call: ' + number.split("@")[0] + '', chalk.hex('#EC7625')(", succes reject")))
        }
     } catch (err) {
        console.log(err)
     }
  }
}

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})