"use strict";
require("dotenv").config();
require("../../../src/Database/JsDB/JSON.js");
const {modul} = require("../Validator/Config");
const {antideleteText} = require("../Validator/Catatan");
const {fs, chalk, moment} = modul;

const deletomesagos = async(rojak, m) => {
try {
    let from = m.key.remoteJid
    let isGroup = from.endsWith('@g.us')
    let isDeleted = isGroup ? antidelete.includes(from) : false
    if (m.key.fromMe) return
    if (!isDeleted) return
    if (m.key.remoteJid == 'status@broadcast') return
    let delkey = m.key
    let c = rojak.chats.get(delkey.remoteJid)
    let a = c.messages.dict[`${delkey.id}|${delkey.fromMe ? 1: 0}`]
    let delcontent = rojak.generateForwardMessageContent(a, false)
    let deltipe = Object.keys(delcontent)[0]
    let teks = `*ANTI DELETE*\n*--> Nama :* @${m.participant.split("@")[0]}\n*--> Waktu :* ${moment.tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm')}\n*--> Tipe :* ${deltipe}`
      await rojak.copyNForward(m.key.remoteJid, m.message)
      await rojak.sendText(m.key.remoteJid, teks, { quoted: m.message, contextInfo: { mentionedJid: [m.participant] }
    }) 
  } catch (err) {
      console.log({err})
    };
  }

module.exports = { deletomesagos } 

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})
