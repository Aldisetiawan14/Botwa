"use strict";
require("dotenv").config();
const {modul} = require("../Validator/Config");
const {announcefalse, announcetrue, anndesc, restrictf, restrictt} = require("../Validator/Catatan");
const {fs, chalk} = modul;

const NoticeGroupM = async(rojak, json) => {
try {
    const metdata = await rojak.groupMetadata(json.jid)
    const pkgg = require('../../../package.json');
    const fkontakk = { 
        key: { 
        fromMe: false, 
        participant: `0@s.whatsapp.net`, ...(json.jid ? { 
        remoteJid: '6283136505591-1604595598@g.us' } : {}
    )}, message: { 
        "contactMessage": {
        "displayName": `${gcdata.subject}`,
        "vcard": `BEGIN:VCARD\n`
        + `VERSION:3.0\n`
        + `N:2;${pkgg.author};;;\n`
        + `FN:${pkgg.version}\n`
        + `item1.TEL;waid=${owner[0]}:+${owner[0]}\n`
        + `item1.X-ABLabel:Mobile\n`
        + `END:VCARD` 
        }
      }
    }
    
if(json.announce == 'false'){ 
   await rojak.sendText(metdata.id, announcefalse(), {
      quoted: fkontakk
   })
   console.log({metdata})
 } else if(json.announce == 'true'){
   await rojak.sendText(metdata.id, announcetrue(), {
      quoted: fkontakk
   })
   console.log({metdata})
 } else if(!json.desc == ''){
   await rojak.sendText(metdata.id, anndesc("💡", json.descOwner.split('@')[0], json.desc), {
      contextInfo: {
      mentionedJid: [ json.descOwner.split('@')[0] + '@s.whatsapp.net' ], 
      quoted: fkontakk
   }
 })
   console.log({metdata})
 } else if(json.restrict == 'false'){
   await rojak.sendText(metdata.id, rsstrictf(), {
      quoted: fkontakk
   })
   console.log({metdata})
 } else if(json.restrict == 'true'){
   await rojak.sendMessage(metdata.id, teks, {
      quoted: fkontakk
   })
   console.log({metdata})
   }
   } catch (err) {
     console.log({err}) 
   } 
 }

module.exports = { NoticeGroupM }

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})