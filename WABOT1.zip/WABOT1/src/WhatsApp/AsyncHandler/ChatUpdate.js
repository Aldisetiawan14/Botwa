"use strict";
require("dotenv").config();
require("../../../src/Database/JsDB/JSON.js");
const {modul, infos, switch_} = require("../Validator/Config");
const {fs, chalk, util, fetch, baileys, moment} = modul;
const {owner, preff} = infos;
const {buggc, multipref, oneprefix, noprefix} = switch_
const {MessageType} = baileys;

exports.getUpdateM = (rojak) => {
  rojak.on("chat-update", async(EM) => {
    if(!EM.hasNewMessage) return
        EM = EM.messages.all()[0]
        await require("../Functions/utilisation")['smsg'](rojak, EM)
    if(EM.messageStubType) {
    if(EM.messageStubType == 68) {
        await rojak.clearMessage(EM.key)
      }
    }
    if(!EM.message) return
    if(EM.key && EM.key.remoteJid == 'status@broadcast') return
        EM.message = (Object.keys(EM.message)[0]=== 'ephemeralMessage') ? EM.message.ephemeralMessage.message : EM.message
    try {
        if ((Object.keys(EM.message)[0] === 'ephemeralMessage' && JSON.stringify(EM.message).includes('EPHEMERAL_SETTING')) && EM.message.ephemeralMessage.message.protocolMessage.type === 3 && buggc && isPublic && !EM.key.fromMe) {
           await rojak.groupRemove(EM.key.remoteJid, [nums]).catch((e) => { reply(`*ERR:* ${e}`) })
           await rojak.sendText(EM.key.remoteJid, antiBug("\n".repeat(420), EM.participant.split('@')[0]), { contextInfo:{ mentionedJid: [ EM.participant + "@s.whatsapp.net"] 
        } 
      })
    }
    const content = JSON.stringify(EM.message)
    const from = EM.key.remoteJid
    const type = Object.keys(EM.message)[0]
    const sender = EM.key.fromMe ? rojak.user.jid : EM.participant ? EM.participant : EM.key.participant ? EM.key.participant : EM.key.remoteJid
    const itsMe = EM.key.fromMe ? true : false
    const isGroup = from.endsWith('@g.us')
    const isOwner = owner.map(v => v + "@s.whatsapp.net").includes(sender);
    const mentionTag = type == "extendedTextMessage" && EM.message.extendedTextMessage.contextInfo != null ? EM.message.extendedTextMessage.contextInfo.mentionedJid : []
    const mentionReply = type == "extendedTextMessage" && EM.message.extendedTextMessage.contextInfo != null ? EM.message.extendedTextMessage.contextInfo.participant || "" : ""
    const mention = typeof(mentionTag) == 'string' ? [mentionTag] : mentionTag
    const mentionUser = mention != undefined ? mention.filter(n => n) : [] 
    const cmd = (type === 'conversation' && EM.message.conversation) ? EM.message.conversation : (type == 'imageMessage') && EM.message.imageMessage.caption ? EM.message.imageMessage.caption : (type == 'videoMessage') && EM.message.videoMessage.caption ? EM.message.videoMessage.caption : (type == 'extendedTextMessage') && EM.message.extendedTextMessage.text ? EM.message.extendedTextMessage.text : (type == 'stickerMessage') && (require('../Functions/stickCmd').getCmd(EM.message.stickerMessage.fileSha256.toString('hex')) !== null && require('../Functions/stickCmd').getCmd(EM.message.stickerMessage.fileSha256.toString('base64')) !== undefined) ? require('../Functions/stickCmd').getCmd(EM.message.stickerMessage.fileSha256.toString('base64')) : "".slice(1).trim().split(/ +/).shift().toLowerCase()
    if (!switch_.isPublic){ 
    if (!isOwner && !itsMe) return
    }
    if (multipref) {
      var prefix = /^[Â°â€¢Ï€Ã·Ã—Â¶âˆ†Â£Â¢â‚¬Â¥Â®â„¢âœ“=|~!?@#%^&.zZ_•\/\\Â©^<+]/.test(cmd) ? cmd.match(/^[Â°â€¢Ï€Ã·Ã—Â¶âˆ†Â£Â¢â‚¬Â¥Â®â„¢âœ“=|~!?@#%^&.zZ_+•\/\\Â©^<+]/gi)[0]: '-'
    } else if (noprefix) {
      prefix = ""
    } else if (oneprefix) {
      prefix = preff
    }
    try { 
      var img = await rojak.getProfilePicture(`${sender.split('@')[0]}@s.whatsapp.net`)
    } catch {
      var img = `https:/\/\i.ibb.co/zZM3ZnK/depositphotos-55820347-stock-illustration-man-or-contact-icon.jpg`
    }
    const buff = await rojak.getBuffer(img)
    const body = (type === 'listResponseMessage' && EM.message.listResponseMessage.title) ? EM.message.listResponseMessage.title : (type === 'buttonsResponseMessage' && EM.message.buttonsResponseMessage.selectedButtonId) ? EM.message.buttonsResponseMessage.selectedButtonId : (type === 'conversation' && EM.message.conversation.startsWith(prefix)) ? EM.message.conversation : (type == 'imageMessage') && EM.message.imageMessage.caption.startsWith(prefix) ? EM.message.imageMessage.caption : (type == 'videoMessage') && EM.message.videoMessage.caption.startsWith(prefix) ? EM.message.videoMessage.caption : (type == 'extendedTextMessage') && EM.message.extendedTextMessage.text.startsWith(prefix) ? EM.message.extendedTextMessage.text : (type == 'stickerMessage') && (require('../Functions/stickCmd').getCmd(EM.message.stickerMessage.fileSha256.toString('base64')) !== null && require('../Functions/stickCmd').getCmd(EM.message.stickerMessage.fileSha256.toString('base64')) !== undefined) ? require('../Functions/stickCmd').getCmd(EM.message.stickerMessage.fileSha256.toString('base64')) : ""
    const messagesC = cmd.slice(0).trim()
    const args = body.trim().split(/ +/).slice(1)
    const totalchat = await rojak.chats.all() 
    const botNumber = rojak.user.jid  
    const isCmd = body.startsWith(prefix)
    const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
    const groupMetadata = isGroup ? await rojak.groupMetadata(from) : ''
    const groupDesc = isGroup ? groupMetadata.desc : ''
    const groupName = isGroup ? groupMetadata.subject : ''
    const groupId = isGroup ? groupMetadata.jid : ''
    const groupMembers = isGroup ? groupMetadata.participants : ''
    const groupAdmins = isGroup ? rojak.getGroupAdmins(groupMembers) : ''
    const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
    const isGroupAdmins = groupAdmins.includes(sender) || false
    const conts = EM.key.fromMe ? rojak.user.jid : rojak.contacts[sender] || { notify: jid.replace(/@.+/, '') }
    const pushname = EM.key.fromMe ? rojak.user.name : conts.notify || conts.vname || conts.name || '-'
    const isButton = (type == 'buttonsResponseMessage') ? EM.message.buttonsResponseMessage.selectedButtonId : ''
    const isListMessage = (type == 'listResponseMessage') ? EM.message.listResponseMessage.singleSelectReply.selectedRowId : '';
    const isMedia = (type === 'imageMessage' || type === 'videoMessage');
    const isImage = (type === 'imageMessage');
    const isVideo = (type === 'videoMessage');
    const isStickers = (type == 'stickerMessage');
    const isListMsg = (type == 'listResponseMessage');
    const isQuotedMsg = type === 'extendedTextMessage' && content.includes('Message');
    const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage');
    const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage');
    const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage');
    const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage');
    const isQuotedDocument = type === 'extendedTextMessage' && content.includes('documentMessage');
    const isQuotedContact = type === 'extendedTextMessage' && content.includes('contactMessage');
    const isQuotedProduct = type === 'extendedTextMessage' && content.includes('productMessage');
    const isQuotedLocation = type === 'extendedTextMessage' && content.includes('locationMessage');
    const isPengunjung = await require("../Functions/visitor").pengunjung.includes(sender);
    const isCatchPengunjung = require("../Functions/visitor").cekPengunjung(sender);
    const isWelkom = isGroup ? welkom.includes(from) : false;
    const isDeleted = isGroup ? antidelete.includes(from) : false;
    const isAntilink = isGroup ? antilinkgroup.includes(from) : false;
    require('../../HandlerChat/Command')['hasCommand']({rojak, EM, isAntilink, isDeleted, isWelkom, botNumber, isPengunjung, isCatchPengunjung, itsMe, prefix, content, from, type, sender, isGroup, isOwner, mentionTag, mentionReply, mention, mentionUser, cmd, body, messagesC, args, totalchat, buff, isCmd, command, groupMetadata, groupDesc, groupName, groupId, groupMembers, groupAdmins, isBotGroupAdmins, isGroupAdmins, conts, pushname, isButton, isListMessage, isMedia, isImage, isVideo, isStickers, isListMsg, isQuotedMsg, isQuotedImage, isQuotedAudio, isQuotedVideo, isQuotedSticker, isQuotedDocument, isQuotedContact, isQuotedProduct, isQuotedLocation})
    } catch (err) {
      console.log({err})
    };
  });
};

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})