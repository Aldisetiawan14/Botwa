"use strict";
require("dotenv").config();
const config = require('./src/WhatsApp/Validator/Config');
const Vt = require('./src/WhatsApp/Functions/utilisation');
const PackM = require('./package.json');
const Constants_1 = require("@adiwajshing/baileys/lib/WAConnection/Constants.js");
const Utils = require("@adiwajshing/baileys/lib/WAConnection/Utils.js");
const pino_1 = require("pino");
const keyed_db_1 = require("@adiwajshing/keyed-db");
const logger = pino_1.default({ prettyPrint: { levelFirst: true, ignore: "hostname", translateTime: true }, prettifier: require("pino-pretty") });
const Encoder_1 = require("@adiwajshing/baileys/lib/Binary/Encoder.js");
const Decoder_1 = require("@adiwajshing/baileys/lib/Binary/Decoder.js");
const {modul, infos} = config;
const {Qrcode_Sesi} = infos;
const {fs, baileys, figlet, chalk, moment} = modul;
const {WAConnection: _WAConnection, ReconnectMode} = baileys;
const WAConnection = Vt.WAConnection(_WAConnection);
const runningBot = async(rojak = new WAConnection()) => {
    console.log(chalk.yellowBright(figlet.textSync(PackM.name, 'Standard')))
    rojak.version = [5, 5537, 46];
    rojak.logger = logger.child({class: PackM.author});
    rojak.logger.level = 'warn';
    rojak.autoReconnect = Constants_1.ReconnectMode.onConnectionLost;
    rojak.browserDescription = Utils.Browsers.ubuntu("SAFARI");
    rojak.connectOptions = {maxIdleTimeMs: 60000, maxRetries: 10, connectCooldownMs: 4000, phoneResponseTime: 15000, maxQueryResponseTime: 10000, alwaysUseTakeover: true, queryChatsTillReceived: true, logQR: true};
    rojak.chatOrderingKey = Utils.waChatKey(false);
    rojak.chats = new keyed_db_1.default(Utils.waChatKey(false), value => value.jid);
    rojak.encoder = new Encoder_1.default();
    rojak.decoder = new Decoder_1.default();
    rojak.on('qr', ({qr}) => console.log({qr: "Please scan to your whatsapp, to run the bot"}))
    fs.existsSync(`./src/Database/JsonDB/session/${Qrcode_Sesi}.json`) && rojak.loadAuthInfo(`./src/Database/JsonDB/session/${Qrcode_Sesi}.json`)
    rojak.on('connecting', () => console.log(chalk.blue.bgRed.bold("connection waiting")));
    rojak.on('open', ({open}) => console.log({open}));
    rojak.on('ws-close', ({reason}) => console.log({reason}));
    rojak.on('close', ({reason, isReconnecting}) => console.log({reason, isReconnecting}));
    await rojak.connect({timeoutMs: 30* 1000}).then(json => console.log({json}))
    fs.writeFileSync(`./src/Database/JsonDB/session/${Qrcode_Sesi}.json`, JSON.stringify(rojak.base64EncodedAuthInfo(), null, "\t"))
    rojak.on("CB:Call", async(json) => {
        await require("./src/WhatsApp/AsyncHandler/CallReject")['rejectPhone'](rojak, json);
    });
    rojak.on("CB:action,,battery", async(json) => {
        await require("./src/WhatsApp/AsyncHandler/BatteryValue")['batteryAsyncOBB'](rojak, json);
    });
    rojak.on("CB:Blocklist", async(json) => { 
        await require("./src/WhatsApp/AsyncHandler/BlockList")['listBlockked'](rojak, json);
    });
    rojak.on("group-participants-update", async(json) => { 
        await require("./src/WhatsApp/AsyncHandler/GroupResponse")['GroupModules'](rojak, json);
    });
    rojak.on("group-update", async(json) => { 
        await require("./src/WhatsApp/AsyncHandler/ChatUpdate")['NoticeGroupM'](rojak, json);
    });
    rojak.on('message-delete', async(m) => {
        await require("./src/WhatsApp/AsyncHandler/MessageDelete")['deletomesagos'](rojak, m);
    });
  await require("./src/WhatsApp/AsyncHandler/ChatUpdate")['getUpdateM'](rojak);
}
runningBot()

let LordROJAK = require.resolve(__filename)
fs.watchFile(LordROJAK, () => {
	fs.unwatchFile(LordROJAK)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[LordROJAK]
	require(LordROJAK)
})